/**
 * Arquivo: fib.c
 * --------------
 * Este programa calcula diversos valores de Fibonacci, utilizando algoritmos
 * iterativos, de recursão simples e de recursão "aditiva" para comparar a
 * eficiência do cálculo entre esses algoritmos. O cálculo da eficiência é feito
 * com a biblioteca "eficiencia.h", que fornece recursos para simplificar a
 * obtenção dos tempos de início, fim e diferença de tempo esses dois extremos.
 *
 * Prof.: Abrantes Araújo Silva Filho
 *        Computação Raiz:
 *            www.computacaoraiz.com.br
 *            www.youtube.com.br/computacaoraiz
 *            github.com/computacaoraiz
 *            twitter.com/ComputacaoRaiz
 *            www.linkedin.com/company/computacaoraiz
 *            www.abrantes.pro.br
 *            github.com/abrantesasf
 */

#include "eficiencia.h"
#include <stdio.h>

/* Constantes simbólicas */

#define MIN 0
#define MAX 55    // aumente por sua conta e risco...
#define PASSO 5

/* Protótipos de subprogramas */

long unsigned int fib_rec (int n);                    // implementação recursiva
long unsigned int fib_ite (int n);                    // implementação iterativa
long unsigned int seq_adit (int n, int t0, int t1);   // implementação geral
long unsigned int fib (int n);                        // wrapper para seq_adit

/* Função main */

int main (void)
{
    pntT inicio, fim;
    double fiter, frecs, freca;

    printf("Comparação dos algoritmos de Fibonacci:\n");
    printf(" N     ITER            REC-S           REC-A\n");
    printf("--------------------------------------------------\n");
    for (int i = MIN; i <= MAX; i += PASSO)
    {
        // Implementação iterativa:
        obter_pnt(&inicio);
        (void) fib_ite(i);
        obter_pnt(&fim);
        fiter = pnt_diff(inicio, fim);

        // Implementação recursiva simples:
        obter_pnt(&inicio);
        (void) fib_rec(i);
        obter_pnt(&fim);
        frecs = pnt_diff(inicio, fim);

        // Implementação como seqüências aditivas:
        obter_pnt(&inicio);
        (void) fib(i);
        obter_pnt(&fim);
        freca = pnt_diff(inicio, fim);

        // Imprime o resultado:
        printf("%2d     %3.9f     %3.9f     %3.9f\n", i, fiter, frecs, freca);
    }
}

/**
 * Função fib_rec
 * Uso: t = fib_rec(n);
 * --------------------
 * Esta função recebe um número inteiro "n" >= 0, e retorna o n-ésimo termo da
 * Seqüência de Fibonacci, utilizando uma implementação recursiva da relação
 * de recorrência:
 *
 *     fib_rec(n) = fib_rec(n - 1) + fib_rec(n - 2)
 *
 * onde: fib_rec(0) = 1
 *       fib_rec(1) = 1.
 *
 * Se o usuário informar um valor inválido (n < 0) a função retorna "-1" como
 * um valor sentinela informativo de input inválido.
 */

long unsigned int fib_rec (int n)
{
    if (n < 0)
        return -1;
    else if (n < 2)
        return n;
    else
        return fib_rec(n - 1) + fib_rec(n - 2);
}

/**
 * Função: fib_ite
 * Uso: n = fib_ite(n);
 * --------------------
 * Esta função recebe um número inteiro "n" >= 0, e retorna o n-ésimo termo da
 * Seqüência de Fibonacci, utilizando uma implementação iterativa através de um
 * array da relação de recorrência:
 *
 *     fib_ite(n) = fib_ite(n - 1) + fib_ite(n - 2)
 *
 * onde: fib_ite(0) = 1
 *       fib_ite(1) = 1.
 *
 * Se o usuário informar um valor inválido (n < 0) a função retorna "-1" como
 * um valor sentinela informativo de input inválido.
 */

long unsigned int fib_ite (int n)
{
    if (n < 0)
        return -1;
    else if (n < 2)
        return n;

    long unsigned int fib[n + 1];
    fib[0] = 0;
    fib[1] = 1;

    for (int i = 2; i <= n; ++i)
        fib[i] = fib[i - 1] + fib[i - 2];

    return fib[n];
}

/**
 * Função: seq_adit
 * Uso: n = seq_adit(n, t0, t1);
 * ----------------------------
 * Esta função recebe 3 números inteiros: t0 e t1 são os dois primeiros números
 * de uma implementação recursiva da relação de recorrência (seqüência aditiva)
 *
 *     seq_adit(n) = seq_adit(n - 1) + seq_adit(n - 2)
 *
 * e n é um número inteiro tal que n >= 0. A função retorna o n-ésimo número
 * da seqüência aditiva gerada utilizando-se como ponto de partida t0 e t1,
 * utilizando como estratégio o fato de que: o n-ésimo termo de uma seqüência
 * aditiva que começa em t0 e t1, é igual ao (n-1)-ésimo termo de uma seqüência
 * aditiva que começa um passo adiante.
 */

long unsigned int seq_adit (int n, int t0, int t1)
{
    if (n < 0)  return -1;
    if (n == 0) return t0;
    if (n == 1) return t1;
    return seq_adit(n - 1, t1, t0 + t1);
}

/**
 * Função: fib
 * Uso: n = fib(n);
 * ----------------
 * Esta função é um wrapper (invólucro) que simplesmente retorna o resultado de
 * outra função mais geral (seq_adit) para o cálculo do n-ésimo termo da
 * Seqüência de Fibonacci.
 */

long unsigned int fib (int n)
{
    if (n < 0) return -1;
    return seq_adit(n, 0, 1);
}
