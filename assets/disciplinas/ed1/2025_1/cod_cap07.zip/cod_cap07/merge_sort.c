/**
 * Arquivo: merge_sort.c
 * Versão : 1.0
 * Data   : 2024-10-07 16:34
 * -------------------------
 * Este programa implementa uma versão simples do Merge Sort para a ordenação de
 * números inteiros, incluindo uma avaliação simples sobre o tempo gasto para a
 * realização da ordenação. O objeto da ordenação (inteiros neste caso) não é o
 * importante aqui: o que importa é que você entenda a mecânica do Merge Sort. O
 * programa solicita ao usuário a quantidade de números que ele quer ordenar e,
 * então, gera um array aleatório com essa quantidade. É sobre esse array que o
 * Merge Sort é realizado.
 *
 * Alguns tempos de ordenação em meu sistema:
 *
 *     -----------------------------
 *               Merge Sort
 *     -----------------------------
 *     N                 T (s)
 *     -----------------------------
 *         1.000         0.000618854
 *         2.500         0.001710206
 *         5.000         0.003546991
 *         7.500         0.005063314
 *        10.000         0.005606306
 *        25.000         0.006829420
 *        50.000         0.009053267
 *        75.000         0.013589757
 *       100.000         0.017126127
 *       250.000         0.042460661
 *       500.000         0.088629550
 *       750.000         0.136676137
 *     1.000.000         0.182864090
 *     -----------------------------
 *
 * Baseado em: Programming Abstractions in C, de Eric S. Roberts.
 *             Capítulo 7: Algorithmic Analysis (pg. 296-303).
 *
 * Prof.: Abrantes Araújo Silva Filho (Computação Raiz)
 *            www.computacaoraiz.com.br
 *            www.youtube.com.br/computacaoraiz
 *            github.com/computacaoraiz
 *            twitter.com/ComputacaoRaiz
 *            www.linkedin.com/company/computacaoraiz
 *            www.abrantes.pro.br
 *            github.com/abrantesasf
 */

#include "eficiencia.h"
#include "genlib.h"
#include "random.h"
#include "simpio.h"
#include "strlib.h"

/* Constantes Simbólicas: */

#define MIN 10
#define MAX 1000000

/* Declarações de Subprogramas: */

void merge_sort (int array[], int n);
static int *copiar_sub_array (int array[], int inicio, int n);
static void combinar (int array[], int arrayE[], int nE, int arrayD[], int nD);

/* Função Main: */

int main (void)
{
    int n;
    do  
    {   
        printf("Quantos números você quer ordenar? ");
        n = GetInteger();
    }   
    while (n < MIN || n > MAX);

    int array[n];

    Randomize();
    
    for (int i = 0; i < n; i++)
        array[i] = RandomInteger(1, 1000000);

    pntT inicio, fim;
    double tempo;

    obter_pnt(&inicio);
    merge_sort(array, n);
    obter_pnt(&fim);
    tempo = pnt_diff(inicio, fim);

    printf("N = %d; Tempo = %5.9f\n", n, tempo);
}

/* Definições de Subprogramas: */

/**
 * Procedimento: merge_sort
 * Uso: merge_sort(array, n);
 * --------------------------
 * Este procedimento ordena os primeiros n elementos de um array em ordem
 * crescente usando o algoritmo Merge Sort, que precisa de: 1) dividir o array
 * em 2 metades; 2) ordenar cada metade; e 3) combinar as metades ordenadas. O
 * procedimento recebe um array de números inteiros e o tamanho n do array.
 */

void merge_sort (int array[], int n)
{
    // Caso simples da recursão: um array com 1 elemente ou vazio
    if (n <= 1)
        return;

    // arrayE = subarray à esquerda; arrayD = subarray à direita
    // nE = tamanho do subarray à esquerda; nD = tamanho do subarray à direita
    int *arrayE, nE, *arrayD, nD;

    // Calcula limites dos subarrays:
    nE = n / 2;
    nD = n - nE;

    // Cria os subarrays à esquerda e à direita:
    arrayE = copiar_sub_array(array, 0, nE);
    arrayD = copiar_sub_array(array, nE, nD);

    // Casos recursivos: ordena os subarrays à esquerda e à direita
    merge_sort(arrayE, nE);
    merge_sort(arrayD, nD);

    // Após a recursão, combina os resultados:
    combinar(array, arrayE, nE, arrayD, nD);

    // Libera os subarrays criados:
    FreeBlock(arrayE);
    FreeBlock(arrayD);
}

/**
 * Função: copiar_sub_array
 * Uso: copiar_sub_array(array, inicio, n);
 * ----------------------------------------
 * Esta função faz uma cópia de um subarray de um array de inteiros e retorna um
 * ponteiro para o novo array dinâmico contendo os novos elementos. O subarray
 * começa na posição de "inicio" do array original, e continua por "n"
 * elementos. Esta função só existe para tornar o código do procedimento
 * merge_sort mais legível. Esta função faz uso da função "NewArray" da CSLIB,
 * que aloca um novo array dinamicamente e retorna um ponteiro para esse array.
 */

static int *copiar_sub_array (int array[], int inicio, int n)
{
    int *resultado;
    resultado = NewArray(n, int);

    for (int i = 0; i < n; i++)
    {
        resultado[i] = array[inicio + i];
    }

    return resultado;
}

/**
 * Procedimento: combinar
 * Uso: combinar(array, arrayE, nE, arrayD, nD);
 * ---------------------------------------------
 * Este procedimento realiza a combinação (merge) de dois arrays já previamente
 * ordenados (arrayE, arrayD) em um único array de saía (array). Como os arrays
 * de entrada já estão ordenados, esta implementação sempre seleciona o primeiro
 * elemento não utilziado em um dos dois arrays de entrada para preencher a
 * próxima posição do array de saída.
 */

static void combinar (int array[], int arrayE[], int nE, int arrayD[], int nD)
{
    // Índices para as posições do array (p), e dos subarrays à esquerda (pE) e
    // à direita (pD):
    int p, pE, pD;
    p = pE = pD = 0;

    // Enquanto há elementos nos dois subarrays:
    while (pE < nE && pD < nD)
        array[p++] = (arrayE[pE] < arrayD[pD]) ? arrayE[pE++] : arrayD[pD++];

    // Se o subarray da direita terminou mas o da esquerda contém elementos:
    while (pE < nE)
        array[p++] = arrayE[pE++];

    // Se o subarray da esquerda terminou mas o da direita contém elementos:
    while (pD < nD)
        array[p++] = arrayD[pD++];
}
