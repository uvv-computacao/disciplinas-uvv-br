/**
 * Arquivo: quick_sort.c
 * Versão : 1.0
 * Data   : 2024-10-08 16:34
 * -------------------------
 * Este programa implementa uma versão simples do Quick Sort para a ordenação de
 * números inteiros, incluindo uma avaliação simples sobre o tempo gasto para a
 * realização da ordenação. O objeto da ordenação (inteiros neste caso) não é o
 * importante aqui: o que importa é que você entenda a mecânica do Quick Sort. O
 * programa solicita ao usuário a quantidade de números que ele quer ordenar e,
 * então, gera um array aleatório com essa quantidade. É sobre esse array que o
 * Quick Sort é realizado.
 *
 * Alguns tempos de ordenação em meu sistema:
 *
 *     -----------------------------
 *               Quick Sort
 *     -----------------------------
 *     N                 T (s)
 *     -----------------------------
 *         1.000         0.000231743
 *         2.500         0.001077546
 *         5.000         0.002264351
 *         7.500         0.003495930
 *        10.000         0.004762044
 *        25.000         0.006162882
 *        50.000         0.007928435
 *        75.000         0.009947799
 *       100.000         0.012134895
 *       250.000         0.029793580
 *       500.000         0.061903133
 *       750.000         0.094444008
 *     1.000.000         0.129125696
 *     -----------------------------
 *
 * Baseado em: Programming Abstractions in C, de Eric S. Roberts.
 *             Capítulo 7: Algorithmic Analysis (pg. 306-312).
 *
 * Prof.: Abrantes Araújo Silva Filho (Computação Raiz)
 *            www.computacaoraiz.com.br
 *            www.youtube.com.br/computacaoraiz
 *            github.com/computacaoraiz
 *            twitter.com/ComputacaoRaiz
 *            www.linkedin.com/company/computacaoraiz
 *            www.abrantes.pro.br
 *            github.com/abrantesasf
 */

#include "eficiencia.h"
#include "genlib.h"
#include "random.h"
#include "simpio.h"

/* Constantes Simbólicas: */

#define MIN 10
#define MAX 1000000

/* Declarações de Subprogramas: */

void quick_sort (int array[], int n);
static int particionar (int array[], int n);
static void trocar (int *a, int *b);

/* Função Main: */

int main (void)
{
    int n;
    do  
    {   
        printf("Quantos números você quer ordenar? ");
        n = GetInteger();
    }   
    while (n < MIN || n > MAX);

    int array[n];

    Randomize();
    
    for (int i = 0; i < n; i++)
        array[i] = RandomInteger(1, 1000000);

    pntT inicio, fim;
    double tempo;

    obter_pnt(&inicio);
    quick_sort(array, n);
    obter_pnt(&fim);
    tempo = pnt_diff(inicio, fim);

    printf("N = %d; Tempo = %5.9f\n", n, tempo);
}

/* Definições de Subprogramas: */

/**
 * Procedimento: quick_sort
 * Uso: quick_sort(array, n);
 * --------------------------
 * Este procedimento ordena os n elementos de um array em ordem crescente
 * utilizando o algoritmo Quick Sort, fazendo: 1) particionando o array
 * em 2 subarrays; e 2) ordenar recursivamente cada subarray. O procedimento
 * recebe um array de números inteiros e o tamanho n do array.
 */

void quick_sort (int array[], int n)
{
    // Caso simples da recursão: um array com 1 elemento ou vazio
    if (n <= 1)
        return;

    // Particiona o array e determina o índice do limite:
    int limite = particionar(array, n);

    // Ordenar recursivamente:
    quick_sort(array, limite);
    quick_sort(array + limite + 1, n - limite - 1);
}

/**
 * Função: particionar
 * Uso: particionar(array, n);
 * ---------------------------
 * Esta função rearranja os elementos de um array relativamente à um valor
 * pivô, que é escolhido arbitrariamente como array[0]. A função retorna o
 * índice de um valor limite tal que:
 *
 *    array[i] <  pivô, para todo i < i do limite
 *    array[i] =  pivô, para i = i do limite
 *    array[i] >= pivô, para todo i > i do limite
 */

static int particionar (int array[], int n)
{
    // Pivô e ponteiros
    int pivo = array[0];
    int pe, pd;
    pe = 1;
    pd = n - 1;

    // Rearranja elementos menores e maiores do que o pivô:
    while (TRUE)
    {
        while (pe < pd && array[pd] >= pivo) pd--;
        while (pe < pd && array[pe] <  pivo) pe++;
        if (pe == pd) break;
        trocar(&array[pe], &array[pd]);
    }

    // Caso o pivô seja o menor elemento:
    if (array[pe] >= pivo) return 0;

    // Caso o pivô não seja o menor elemento:
    array[0] = array[pe];
    array[pe] = pivo;
    return pe;    
}

/**
 * Procedimento: trocar
 * Uso: trocar(*a, *b);
 * --------------------
 * Este procedimento recebe dois ponteiros para números inteiros e realiza
 * a troca desses números, ou seja, a = b e b = a.
 */

static void trocar (int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}
