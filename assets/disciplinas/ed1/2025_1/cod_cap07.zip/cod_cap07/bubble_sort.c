/**
 * Arquivo: bubble_sort.c
 * Versão : 1.0
 * Data   : 2024-10-06 20:36
 * -------------------------
 * Este programa implementa uma versão simples do Bubble Sort para a
 * ordenação de números inteiros, incluindo uma avaliação simples sobre o tempo
 * gasto para a realização da ordenação. O objeto da ordenação (inteiros neste
 * caso) não é o importante aqui: o que importa é que você entenda a
 * mecânica do Bubble Sort. O programa solicita ao usuário a quantidade
 * de números que ele quer ordenar e, então, gera um array aleatório com
 * essa quantidade. É sobre esse array que o Bubble Sort é realizado. Também é
 * apresentada uma versão um pouco mais otimizada do Bubble Sort, que termina a
 * ordenação de modo precoce se não for feita nenhuma troca no array.
 *
 * Alguns tempos de ordenação em meu sistema:
 *
 *     -----------------------------
 *              Bubble Sort
 *     -----------------------------
 *     N                 T (s)
 *     -----------------------------
 *         1.000         0.003878389
 *         2.500         0.015195672
 *         5.000         0.071982125
 *         7.500         0.129035398
 *        10.000         0.232493986
 *        25.000         1.553097368
 *        50.000         6.514312710
 *        75.000        14.882730837
 *       100.000        26.301346291
 *       250.000       169.332235394
 *       500.000       673.885925938
 *       750.000      1486.167077780
 *     1.000.000      2676.016201590
 *     -----------------------------
 *
 * Baseado em: Algorithms in C, de Robert Sedgewick
 *             1ª ed (100-101)
 *
 * Prof.: Abrantes Araújo Silva Filho
 *        Computação Raiz:
 *            www.computacaoraiz.com.br
 *            www.youtube.com.br/computacaoraiz
 *            github.com/computacaoraiz
 *            twitter.com/ComputacaoRaiz
 *            www.linkedin.com/company/computacaoraiz
 *            www.abrantes.pro.br
 *            github.com/abrantesasf
 */

#include <ctype.h>
#include "eficiencia.h"
#include "genlib.h"
#include "random.h"
#include "simpio.h"

/* Constantes simbólicas: */

#define MIN 10
#define MAX 1000000

/* Declarações de Subprogramas: */

void trocar (int *a, int *b);
void bubble_sort (int array[], int tam);
void bubble_sort2 (int array[], int tam);

/* Função Main: */

int main (void)
{
    int n;
    do
    {
        printf("Quantos números você quer ordenar? ");
        n = GetInteger();
    }
    while (n < MIN || n > MAX);

    int array[n];

    Randomize();
    
    for (int i = 0; i < n; i++)
        array[i] = RandomInteger(1, 1000000);

    pntT inicio, fim;
    double tempo;

    obter_pnt(&inicio);
    bubble_sort(array, n);
    obter_pnt(&fim);
    tempo = pnt_diff(inicio, fim);

    printf("N = %d; Tempo = %5.9f\n", n, tempo);

}

/* Definições de Subprogramas: */

/**
 * Procedimento: bubble_sort
 * Uso: bubble_sort(array, tam);
 * -----------------------------
 * Este procedimento recebe um array de número inteiros, teoricamente não
 * ordenados, e também o tamanho desse array (número de elementos), e faz a
 * ordenação dos números nesse array utilizando uma das possíveis implementações
 * do algoritmo Bubble Sort. A troca é feita chamando-se o procedimento
 * "trocar".
 */

void bubble_sort (int array[], int tam)
{
    for (int i = tam - 1; i >= 0; i--)
        for (int j = 1; j <= i; j++)
            if (array[j - 1] > array[j])
                trocar(&array[j - 1], &array[j]);
}

/**
 * Procedimento: bubble_sort2
 * Uso: bubble_sort2(array, tam);
 * ------------------------------
 * Este procedimento recebe um array de número inteiros, teoricamente não
 * ordenados, e também o tamanho desse array (número de elementos), e faz a
 * ordenação dos números nesse array utilizando uma das possíveis implementações
 * do algoritmo Bubble Sort. A troca é feita chamando-se o procedimento
 * "trocar". A diferença entre este procedimento e o anterior, é que neste
 * procedimento há uma verificação se ocorreu ou não alguma troca: se não
 * ocorreu troca é porque o array está ordenado e, assim, o procedimento pode
 * ser interrompido precodemente.
 */

void bubble_sort2 (int array[], int tam)
{
    bool troca;
    for (int i = tam - 1; i >= 0; i--)
    {
        troca = FALSE;
        for (int j = 1; j <= i; j++)
        {
            if (array[j - 1] > array[j])
            {
                trocar(&array[j - 1], &array[j]);
                troca = TRUE;
            }
        }
        if (troca == FALSE)
            break;
    }
}

/**
 * Procedimento: trocar
 * Uso: trocar(*a, *b);
 * --------------------
 * Este procedimento recebe dois ponteiros para números inteiros e realiza
 * a troca desses números, ou seja, a = b e b = a.
 */

void trocar (int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}
