/**
 * Arquivo: insertion_sort.c
 * Versão : 1.0
 * Data   : 2024-10-03 18:27
 * -------------------------
 * Este programa implementa uma versão simples do Insertion Sort para a
 * ordenação de números inteiros, incluindo uma avaliação simples sobre o tempo
 * gasto para a realização da ordenação. O objeto da ordenação (inteiros neste
 * caso) não é o importante aqui: o que importa é que você entenda a
 * mecânica do Insertion Sort. O programa solicita ao usuário a quantidade
 * de números que ele quer ordenar e, então, gera um array aleatório com
 * essa quantidade. É sobre esse array que o Insertion Sort é realizado.
 *
 * Alguns tempos de ordenação em meu sistema:
 *
 *     -----------------------------
 *             Insertion Sort
 *     -----------------------------
 *     N                 T (s)
 *     -----------------------------
 *         1.000         0.002665964
 *         2.500         0.007699986
 *         5.000         0.017275266
 *         7.500         0.032358893
 *        10.000         0.055539730
 *        25.000         0.314092648
 *        50.000         1.218458801
 *        75.000         2.762859599
 *       100.000         4.925750682
 *       250.000        30.694431502
 *       500.000       123.409269984
 *       750.000       279.138751696
 *     1.000.000       500.896221395
 *     -----------------------------
 *
 * Baseado em: Introduction to Algorithms, de Cormen et al.
 *             4ª ed. (17-24)
 *
 * Prof.: Abrantes Araújo Silva Filho
 *        Computação Raiz:
 *            www.computacaoraiz.com.br
 *            www.youtube.com.br/computacaoraiz
 *            github.com/computacaoraiz
 *            twitter.com/ComputacaoRaiz
 *            www.linkedin.com/company/computacaoraiz
 *            www.abrantes.pro.br
 *            github.com/abrantesasf
 */

#include "eficiencia.h"
#include "genlib.h"
#include "random.h"
#include "simpio.h"

/* Constantes simbólicas: */

#define MIN 10
#define MAX 1000000

/* Declarações de Subprogramas: */

void insertion_sort (int array[], int tam);

/* Função Main: */

int main (void)
{
    int n;
    do
    {
        printf("Quantos números você quer ordenar? ");
        n = GetInteger();
    }
    while (n < MIN || n > MAX);

    int array[n];

    Randomize();
    
    for (int i = 0; i < n; i++)
        array[i] = RandomInteger(1, 1000000);

    pntT inicio, fim;
    double tempo;

    obter_pnt(&inicio);
    insertion_sort(array, n);
    obter_pnt(&fim);
    tempo = pnt_diff(inicio, fim);

    printf("N = %d; Tempo = %5.9f\n", n, tempo);

}

/* Definições de Subprogramas: */

/**
 * Procedimento: insertion_sort
 * Uso: insertion_sort(array, tam);
 * --------------------------------
 * Este procedimento recebe um array de número inteiros, teoricamente não
 * ordenados, e também o tamanho desse array (número de elementos), e faz a
 * ordenação dos números nesse array utilizando uma das possíveis implementações
 * do algoritmo Insertion Sort. A troca é feita chamando-se o procedimento
 * "trocar".
 */

void insertion_sort (int array[], int tam)
{
    for (int i = 1; i < tam; i++)
    {
        int chave = array[i];
        int j = i - 1;
        while (j >= 0 && array[j] > chave)
        {
            array[j + 1] = array[j];
            j = j - 1;
        }
        array[j + 1] = chave;
    }
}
