/**
 * Arquivo: selection_sort.c
 * Versão : 1.0
 * Data   : 2024-09-16 17:49
 * -------------------------
 * Este programa implementa uma versão simples do Selection Sort para a
 * ordenação de números inteiros, incluindo uma avaliação simples sobre o tempo
 * gasto para a realização da ordenação. O objeto da ordenação (inteiros neste
 * caso) não é o importante aqui: o que importa é que você entenda a
 * mecânica do Selection Sort. O programa solicita ao usuário a quantidade
 * de números que ele quer ordenar e, então, gera um array aleatório com
 * essa quantidade. É sobre esse array que o Selection Sort é realizado.
 *
 * Alguns tempos de ordenação em meu sistema:
 *
 *     -----------------------------
 *             Selection Sort
 *     -----------------------------
 *     N                 T (s)
 *     -----------------------------
 *         1.000         0,004929366
 *         2.500         0,010312282
 *         5.000         0,027220584
 *         7.500         0,054995412
 *        10.000         0,094631551
 *        25.000         0,558033754
 *        50.000         2,207042104
 *        75.000         4,959149477
 *       100.000         8,791371990
 *       250.000        55,038402343
 *       500.000       220,460744582
 *       750.000       495,756866120
 *     1.000.000       884,514292304
 *     -----------------------------
 *
 * Baseado em: Programming Abstractions in C, de Eric S. Roberts.
 *             Capítulo 7: Algorithmic Analysis (pg. 283-288).
 *
 * Prof.: Abrantes Araújo Silva Filho
 *        Computação Raiz:
 *            www.computacaoraiz.com.br
 *            www.youtube.com.br/computacaoraiz
 *            github.com/computacaoraiz
 *            twitter.com/ComputacaoRaiz
 *            www.linkedin.com/company/computacaoraiz
 *            www.abrantes.pro.br
 *            github.com/abrantesasf
 */

#include "eficiencia.h"
#include "genlib.h"
#include "random.h"
#include "simpio.h"

/* Constantes simbólicas: */

#define MIN 10
#define MAX 1000000

/* Declarações de Subprogramas: */

void trocar (int *a, int *b);
void selection_sort (int array[], int tam);

/* Função Main: */

int main (void)
{
    int n;
    do
    {
        printf("Quantos números você quer ordenar? ");
        n = GetInteger();
    }
    while (n < MIN || n > MAX);

    int array[n];

    Randomize();
    
    for (int i = 0; i < n; i++)
        array[i] = RandomInteger(1, 1000000);

    pntT inicio, fim;
    double tempo;

    obter_pnt(&inicio);
    selection_sort(array, n);
    obter_pnt(&fim);
    tempo = pnt_diff(inicio, fim);

    printf("N = %d; Tempo = %5.9f\n", n, tempo);

}

/* Definições de Subprogramas: */

/**
 * Procedimento: selection_sort
 * Uso: selection_sort(array, tam);
 * --------------------------------
 * Este procedimento recebe um array de número inteiros, teoricamente não
 * ordenados, e também o tamanho desse array (número de elementos), e faz a
 * ordenação dos números nesse array utilizando uma das possíveis implementações
 * do algoritmo Selection Sort. A troca é feita chamando-se o procedimento
 * "trocar".
 */

void selection_sort (int array[], int tam)
{
    int menor;

    for (int i = 0; i < tam; i++)
    {
        menor = i;
        for (int j = i + 1; j < tam; j++)
            if (array[j] < array[menor])
                menor = j;
        trocar(&array[i], &array[menor]);
    }
}

/**
 * Procedimento: trocar
 * Uso: trocar(*a, *b);
 * --------------------
 * Este procedimento recebe dois ponteiros para números inteiros e realiza
 * a troca desses números, ou seja, a = b e b = a.
 */

void trocar (int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}
