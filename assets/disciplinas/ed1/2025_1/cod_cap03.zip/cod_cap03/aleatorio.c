/**
 * Arquivo: aleatorio.c
 * --------------------
 * Este arquivo implementa a interface aleatorio.h.
 */

#include "aleatorio.h"
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/**
 * Função: inteiro_aleatorio
 * Uso: n = inteiro_aleatorio(min, max);
 * -------------------------------------
 * Esta função retorna um número inteiro aleatório no intervalo FECHADO
 * [min, max], significando que o resultado é sempre maior do que ou igual à
 * "min" e menor do que ou igual à "max".
 *
 * Ela inicia usando rand para selecionar um inteiro no intervalo [0, RAND_MAX]
 * e, então, converte esse inteiro para o intervalo desejado pelo usuário em
 * [min, max] através dos seguintes passos:
 *
 * 1. Normalizar o valor para um double no intervalo [0, 1);
 * 2. Escalar o resultado para um valor na faixa desejada;
 * 3. Truncar o resultado para um inteiro;
 * 4. Ajustar o resultado de acordo com o ponto de início apropriado.
 */

int inteiro_aleatorio (int min, int max)
{
    int k;
    double d;

    d = (double) rand() / ((double) RAND_MAX + 1);   // normaliza para [0, 1)
    k = (int) (d * (max - min + 1));                 // escala e trunca
    return (min + k);                                // ajusta para o início
}

/**
 * Função: double_aleatorio
 * Uso: d = double_aleatorio(min, max);
 * ------------------------------------
 * Esta função retorna um número double aleatório no intervalo SEMI-ABERTO À
 * DIREITA [min, max), significando que o resultado seja sempre maior do que ou
 * iqual à "min", mas estritamente menor do que "max".
 *
 * A implementação é semelhante à implementação da função "inteiro_aleatorio",
 * sem o passo de truncar o resultado para um inteiro.
 */

double double_aleatorio (double min, double max)
{
    double d;

    d = (double) rand() / ((double) RAND_MAX + 1);   // normaliza em [0, 1)
    d = d * (max - min);                             // escala
    return (min + d);                                // ajusta para o início
}

/**
 * Predicado: ao_acaso
 * Uso: if (ao_acaso(p)) ...
 * -------------------------
 * Este predicado retorna "true" com probabilidade indicada por "p", que deve
 * ser um double entre 0.0 (nunca) e 1.0 (sempre). Por exemplo: chamar o
 * predicado ao_acaso(0.30) returna "true" em 30% das vezes.
 *
 * Usa a função "double_aleatorio" para gerar um número real entre [0, 1) e
 * compara esse valor com a probabilidade p informada pelo usuário.
 */

bool ao_acaso (double p)
{
    return (double_aleatorio(0.0, 1.0) < p);
}

/**
 * Procedimento: randomizar
 * Uso: randomizar();
 * ------------------
 * Este procedimento inicializa o gerador de números pseudo-aleatórios para que
 * seus resultados sejam imprevisíveis. Se este procedimento não for chamado, os
 * outros subprogramas retornarão sempre os mesmos valores.
 *
 * Faz o ajuste do seed para a geração de númeos pseudo-aleatórios utilizando a
 * hora atual do sistema e o procedimento srand. O procedimento srand é definido
 * na biblioteca <stdlib.h> e requer como argumento um número inteiro. A função
 * time é definida na biblioteca <time.h>.
 */

void randomizar (void)
{
    srand((unsigned int) time(NULL));
}

