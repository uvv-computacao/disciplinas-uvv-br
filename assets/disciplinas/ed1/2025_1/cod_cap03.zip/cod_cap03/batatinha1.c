/**
 * Arquivo: batatinha1.c
 * Versão : 1.0
 * Data   : 2025-03-09 18:19
 * -------------------------
 * Este programa demonstra o uso de arquivos de texto em C, fazendo a
 * transferência de informações caractere a caractere com as funções:
 * getc, ungetc e putc.
 */

/*** Includes ***/

#include <CRpaic.h>
#include <stdio.h>
#include <stdlib.h>

/*** Declaração de Subprogramas ***/

/**
 * Procedimento: copiar_arquivo
 * Uso: copiar_arquivo(entrada, saida);
 * ------------------------------------
 * Este procedimento recebe dois ponteiros para arquivos, entrada e saída, e
 * faz a cópia do arquivo de entrada para o arquivo de saída. O usuário é
 * responsável por garantir que os ponteiros sejam válidos! Se o usuário não
 * passar arquivos válidos, o comportamento é indefinido.
 */

void copiar_arquivo (FILE *entrada, FILE *saida);

/*** Função Main: ***/

int main (void)
{
    // Cria os ponteiros para arquivos:
    FILE *entrada, *saida;

    // Abre o arquivo batatinha.txt para leitura:
    entrada = fopen("batatinha.txt", "r");
    if (!entrada)
    {
        fprintf(stderr, "Arquivo input não encontrado.\n");
        return EXIT_FAILURE;
    }

    // Abre o arquivo batatinha_copia.txt para escrita:
    saida = fopen("batatinha_copia.txt", "w");
    if (!saida)
    {
        fprintf(stderr, "Arquivo output não encontrado.\n");
        fclose(entrada);
        return EXIT_FAILURE;
    }

    // Com os ponteiros válidos, faz a cópia:
    copiar_arquivo(entrada, saida);

    // Fecha arquivos:
    fclose(entrada);
    fclose(saida);

    // Finaliza:
    return EXIT_SUCCESS;
}

/**
 * Procedimento: copiar_arquivo
 * Uso: copiar_arquivo(entrada, saida);
 * ------------------------------------
 */

void copiar_arquivo (FILE *entrada, FILE *saida)
{
    int c;

    while ((c = getc(entrada)) != EOF)
        putc(c, saida);
}
