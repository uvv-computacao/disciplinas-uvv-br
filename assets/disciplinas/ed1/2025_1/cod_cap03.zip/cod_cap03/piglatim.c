/**
 * Arquivo: piglatin.c
 * Versão 2.0
 * Em 2025/03/09 15:15
 * -------------------
 * Implementa o jogo de palavras americano chamado de Pig Latin, que converte
 * palavras para o vocabulário "Pig Latin" conforme as seguintes regras:
 *
 *   1. Se a palavra não contém vogais, nenhuma conversão é feita, ou seja,
 *      a palavra "traduzida" é idêntica à original;
 *   2. Se a palavra começa com uma vogal, adiciona-se o sufixo "way" ao final
 *      da palavra original: "any" torna-se "anyway"; e
 *   3. Se a palavra começa com uma consoante, extraímos a seqüencia de
 *      consoantes iniciais, até encontrar a primeira vogal, colocamos essa
 *      seqüência de consoantes como sufixo e, depois, adicionamos ainda mais
 *      um sufixo final, o "ay": "trash" torna-se "ashtray".
 */

/*** Includes ***/

#include <CRpaic.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

/*** Constantes Simbólicas ***/

/**
 * Constante: SUFMAX, SUFMIN
 * -------------------------
 * Definem o tamanho do maior e do menor sufixo a ser acrescentado à palavra
 * original no momento da tradução para o Pig Latin. São três situações: ou a
 * palavra não se altera (e, portanto não tem sufixo), ou é acrescida de "way"
 * (que é o maior sufixo) ou é acrescida de "ay" (que é o menor sufixo).
 */

#define SUFMAX 3
#define SUFMIN 2

/*** Tipos de Dados ***/

/**
 * Tipo: en_status, statusT
 * ------------------------
 * Tipo de dado genérico para indicar retornos de funções. Se a função não foi
 * executada com sucesso, retorna NOK; se foi executada com sucesso, retorna OK.
 */

enum en_status
{
    NOK,
    OK
};

typedef enum en_status statusT;

/*** Definições de Subprogramas ***/

/**
 * Predicado: e_vogal
 * Uso: if (e_vogal(char)) . . .
 * -----------------------------
 * Este predicado recebe um único caractere e retorna TRUE se o caractere
 * for uma vogal, e FALSE caso contrário.
 *
 * LIMITAÇÃO: só funciona com caracteres ASCII no momento!
 */

bool e_vogal (const char c);

/**
 * Função: achar_primeira_vogal
 * Uso: p = achar_primeira_vogal(palavra);
 * ---------------------------------------
 * Esta função recebe uma string (como array ou ponteiro para char) e retorna um
 * ponteiro para a primeira vogal na palavra. Se a palavra não tiver nenhuma
 * vogal, retorna NULL.
 */

static char *
achar_primeira_vogal (char *palavra);

/**
 * Função: pig_latin
 * Uso: if (pig_latin(palavra, buffer, tamanho_buffer)) . . .
 * ----------------------------------------------------------
 * Esta função traduz uma palavra qualquer em seu equivalente em PigLatin.
 * A palavra traduzida é escrita no buffer, que tem um tamanho pré-alocado dado
 * pelo último elemento. O código verifica se ocorrerá buffer overflow e gera
 * uma mensagem de erro se isso ocorrer. O usuário tem a responsabilidade de
 * passar uma palavra e um buffer válido (e o tamanho correto do buffer). Se
 * a tradução foi feita corretamente, retorna um statusT de OK, caso contrário
 * retorna um statusT de NOK.
 */

static statusT
pig_latin (char *palavra, char buffer[], int tamanho_buffer);

/*** Função MAIN ***/

int main (void)
{
    // Obtém palava do usuário:
    string palavra = get_string("Informe uma palavra: ");

    // Cria buffer adequado para a palavra com o maior sufixo:
    int tamanho_buffer = strlen(palavra) + 1 + SUFMAX;
    char buffer[tamanho_buffer];
    // Inicializa buffer inteiro como \0:
    memset(buffer, 0, tamanho_buffer);

    // Faz a tradução:
    if (pig_latin(palavra, buffer, tamanho_buffer))
        printf("Pig Latin: %s\n", buffer);
    else
    {
        fprintf(stderr, "Erro na tradução!\n");
        // Não precisa liberar "palavra", CRpaic faz isso aqui
        // Não precisa liberar "buffer", pois está no stack
        return EXIT_FAILURE;
    }

    // Finaliza:
    // (não precisa liberar "palavra", CRpaic faz isso aqui)
    return EXIT_SUCCESS;
}

/**
 * Predicado: e_vogal
 * Uso: if (e_vogal(char)) . . .
 * -----------------------------
 */

bool e_vogal (const char c)
{
    switch (c)
    {
    case 'a': case 'e': case 'i': case 'o': case 'u':
    case 'A': case 'E': case 'I': case 'O': case 'U':
        return true;
        break;
    }
    return false;
}

/**
 * Função: achar_primeira_vogal
 * Uso: p = achar_primeira_vogal(palavra);
 * ---------------------------------------
 */

static char *
achar_primeira_vogal (char *palavra)
{
    for (char *p = palavra; *p != '\0'; p++)
    {
        if (e_vogal(*p))
            return p;
    }

    return NULL;
}

/**
 * Função: pig_latin
 * Uso: if (pig_latin(palavra, buffer, tamanho_buffer)) . . .
 * ----------------------------------------------------------
 */

static statusT
pig_latin (char *palavra, char buffer[], int tamanho_buffer)
{
    if (!palavra || !buffer || tamanho_buffer <= 0)
        return NOK;
    
    int tam = strlen(palavra);
    
    char *pv = achar_primeira_vogal(palavra);

    if (pv == palavra)
        tam += SUFMAX;
    else if (pv != NULL)
        tam += SUFMIN;

    if (tam >= tamanho_buffer)
        return NOK;

    if (pv == NULL)
        strcpy(buffer, palavra);
    else if (pv == palavra)
    {
        strcpy(buffer, palavra);
        strcat(buffer, "way");
    }
    else
    {
        strcpy(buffer, pv);
        strncat(buffer, palavra, pv - palavra);
        strcat(buffer, "ay");
    }

    return OK;
}
