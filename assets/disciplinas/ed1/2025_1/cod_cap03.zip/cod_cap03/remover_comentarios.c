/**
 * Arquivo: remover_comentarios.c
 * Versão : 1.0
 * Data   : 2025-03-09 19:03
 * -------------------------
 * Este programa faz a cópia de um aquivo de entrada para um arquivo de saída,
 * removendo comentários entre /* e */

/*** Includes ***/

#include <CRpaic.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

/*** Declarações de Subprogramas ***/

/**
 * Procedimento: copiar_removendo_comentarios
 * Uso: copiar_removendo_comentario(entrada, saida);
 * -------------------------------------------------
 * Este procedimento faz a copia do arquivo de "entrada" para o arquivo de
 * "saida", removendo todos os comentários de bloco. Recebe dois ponteiros para
 * arquivos, que devem ser ponteiros válidos (o usuário é responsável de passar
 * ponteiros de arquivos válidos).
 */

void copiar_removendo_comentarios (FILE *entrada, FILE *saida);

/*** Função Main: ***/

int main (void)
{
    FILE *entrada, *saida;

    entrada = fopen("comentarios.txt", "r");
    if (!entrada)
    {
        fprintf(stderr, "Impossível abrir a entrada.\n");
        return EXIT_FAILURE;
    }

    saida = fopen("comentarios_removidos.txt", "w");
    if (!saida)
    {
        fprintf(stderr, "Impossível abrir a saída.\n");
        fclose(entrada);
        return EXIT_FAILURE;
    }

    copiar_removendo_comentarios(entrada, saida);

    fclose(entrada);
    fclose(saida);

    return EXIT_SUCCESS;
}

/*** Definições de Subprogramas ***/

/**
 * Procedimento: copiar_removendo_comentarios
 * Uso: copiar_removendo_comentario(entrada, saida);
 * -------------------------------------------------
 * Este procedimento faz a copia do arquivo de "entrada" para o arquivo de
 * "saida", removendo todos os comentários de bloco. Recebe dois ponteiros para
 * arquivos, que devem ser ponteiros válidos (o usuário é responsável de passar
 * ponteiros de arquivos válidos).
 */

void copiar_removendo_comentarios (FILE *entrada, FILE *saida)
{
    int c, prox_c;
    bool comentario = false;

    while ((c = getc(entrada)) != EOF)
    {
        if (comentario)
        {
            if (c == '*')
            {
                prox_c = getc(entrada);
                if (prox_c == '/')
                    comentario = false;
                else
                    ungetc(prox_c, entrada);
            }
        }
        else
        {
            if (c == '/')
            {
                prox_c = getc(entrada);
                if (prox_c == '*')
                    comentario = true;
                else
                    ungetc(prox_c, entrada);
            }

            if (!comentario)
                putc(c, saida);
        }
        
    }
}
