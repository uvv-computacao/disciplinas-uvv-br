/**
 * Arquivo: par_impar.c
 * --------------------
 * Este programa implementa um exemplo de algoritmo com recursão mútua,
 * retornando TRUE se um determinado número inteiro n é par. O número 0 (zero)
 * é considerado par por definição; qualquer outro número é par se o seu
 * antecessor for ímpar. Note que limitamos os números de entrada aos conjunto
 * de inteiros UNSIGNED e, portanto, aos números naturais (ou seja, este
 * programa não é aplicável aos números negativos).
 *
 * BUG: grandes valores de n causam um número gigante de chamadas recursivas e,
 *      assim, terminam em stack overflow.
 *
 * Fonte: Programming Abstractions in C, de Eric S. Roberts
 *        Capítulo 4: Introduction to Recursion (pg. 182-184)
 *
 * Prof.: Abrantes Araújo Silva Filho
 */

#include "genlib.h"
#include <stdio.h>
#include "strlib.h"

/* Protótipos dos subprogramas */
bool e_par(unsigned int n);
bool e_impar(unsigned int n);

/* Função main */

int main (void)
{
    printf("%d\n", e_par(54326));
}

/* Definição dos subprogramas */

/**
 * Predicado: e_par
 * Uso: if (e_par(n)) . . .
 * ------------------------
 * Este predicado retorna TRUE se o inteiro n for par. O número 0 é considerado
 * par por definição; qualquer outro número é par se o seu antecessor for ímpar.
 * O predicado só aceita argumentos unsigned.
 */

bool e_par(unsigned int n)
{
    if (n == 0)
        return TRUE;
    else
        return e_impar(n - 1);
}

/**
 * Predicado: e_impar
 * Uso: if (e_impar(n)) . . .
 * --------------------------
 * Este predicado retorna TRUE se n é ímpar, onde um número é definido como
 * ímpar se ele não for par. O predicado só aceita argumentos unsigned.
 */

bool e_impar(unsigned int n)
{
    return (!e_par(n));

    // Uma outra implementação possível:
    #if 0
    if (n == 0)
        return FALSE;
    else
        return (e_par(n - 1));
    #endif
}
