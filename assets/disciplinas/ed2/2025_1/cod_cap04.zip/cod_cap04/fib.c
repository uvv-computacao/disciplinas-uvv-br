/**
 * Arquivo: fib.c
 * --------------
 * Este programa lista os termos de uma Seqüência de Fibonacci, com índices
 * variando de min (valor mínimo) até max (valor máximo).
 */

#include <cs50.h>
#include <stdio.h>

/* Constantes simbólicas */

#define MIN 0
#define MAX 45

/* Protótipos de subprogramas */

int fib_rec (int n);                    // implementação recursiva
int fib_ite (int n);                    // implementação iterativa
int seq_adit (int n, int t0, int t1);   // implementação geral
int fib (int n);                        // wrapper para fib

/* Função main */

int main (void)
{
    printf("Este programa lista alguns números da Seqüência de Fibonacci.\n");
    for (int i = MIN; i <= MAX; i++)
        printf("fib(%2d) = %10d\n", i, seq_adit(i, 0, 1));
}

/**
 * Função fib_rec
 * Uso: t = fib_rec(n);
 * --------------------
 * Esta função recebe um número inteiro "n" >= 0, e retorna o n-ésimo termo da
 * Seqüência de Fibonacci, utilizando uma implementação recursiva da relação
 * de recorrência:
 *
 *     fib_rec(n) = fib_rec(n - 1) + fib_rec(n - 2)
 *
 * onde: fib_rec(0) = 1
 *       fib_rec(1) = 1.
 *
 * Se o usuário informar um valor inválido (n < 0) a função retorna "-1" como
 * um valor sentinela informativo de input inválido.
 */

int fib_rec (int n)
{
    if (n < 0)
        return -1;
    else if (n < 2)
        return n;
    else
        return fib_rec(n - 1) + fib_rec(n - 2);
}

/**
 * Função: fib_ite
 * Uso: n = fib_ite(n);
 * --------------------
 * Esta função recebe um número inteiro "n" >= 0, e retorna o n-ésimo termo da
 * Seqüência de Fibonacci, utilizando uma implementação iterativa através de um
 * array da relação de recorrência:
 *
 *     fib_ite(n) = fib_ite(n - 1) + fib_ite(n - 2)
 *
 * onde: fib_ite(0) = 1
 *       fib_ite(1) = 1.
 *
 * Se o usuário informar um valor inválido (n < 0) a função retorna "-1" como
 * um valor sentinela informativo de input inválido.
 */

int fib_ite (int n)
{
    if (n < 0)
        return -1;
    else if (n < 2)
        return n;

    int fib[n + 1];
    fib[0] = 0;
    fib[1] = 1;

    for (int i = 2; i <= n; ++i)
        fib[i] = fib[i - 1] + fib[i - 2];

    return fib[n];
}

/**
 * Função: seq_adit
 * Uso: n = seq_adit(n, t0, t1);
 * ----------------------------
 * Esta função recebe 3 números inteiros: t0 e t1 são os dois primeiros números
 * de uma implementação recursiva da relação de recorrência (seqüência aditiva)
 *
 *     seq_adit(n) = seq_adit(n - 1) + seq_adit(n - 2)
 *
 * e n é um número inteiro tal que n >= 0. A função retorna o n-ésimo número
 * da seqüência aditiva gerada utilizando-se como ponto de partida t0 e t1,
 * utilizando como estratégio o fato de que: o n-ésimo termo de uma seqüência
 * aditiva que começa em t0 e t1, é igual ao (n-1)-ésimo termo de uma seqüência
 * aditiva que começa um passo adiante.
 */

int seq_adit (int n, int t0, int t1)
{
    if (n < 0)  return -1;
    if (n == 0) return t0;
    if (n == 1) return t1;
    return seq_adit(n - 1, t1, t0 + t1);
}

/**
 * Função: fib
 * Uso: n = fib(n);
 * ----------------
 * Esta função é um wrapper (invólucro) que simplesmente retorna o resultado de
 * outra função mais geral (seq_adit) para o cálculo do n-ésimo termo da
 * Seqüência de Fibonacci.
 */

int fib (int n)
{
    if (n < 0) return -1;
    return seq_adit(n, 0, 1);
}
