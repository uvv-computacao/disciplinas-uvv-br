#include <stdio.h>

int main (void)
{
    
}

void coletar_contribuicoes(int valor)
{
    if (valor <= 100)
    {
        // Coletar a contribuição
    }
    else
    {
        // Encontrar mais 10 pessoas
        coletar_contribuicoes(valor/10);
        // Combinar o dinheiro arrecadado pelas pessoas
    }
}


/* tipo */ subprograma_recursivo (/* parâmetros */)
{
    if (/* teste para o caso simples */)
    {
        // Obter uma solução simples SEM USAR recursão
    }
    else
    {
        // Quebrar o problema em subproblemas menoras com a mesma forma
        // Resolver cada subproblema chamando o próprio subprograma_recursivo
        // Combinar as soluções dos subproblemas na solução unificada do todo
    }
}

