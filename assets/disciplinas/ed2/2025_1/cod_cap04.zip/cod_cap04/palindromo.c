/**
 * Arquivo: palindromo.c
 * ---------------------
 * Este programa implementa alguns exemplos de algoritmos recursivos para a
 * identificação de palavras que são palíndromos.
 *
 * Fonte: Programming Abstractions in C, de Eric S. Roberts
 *        Capítulo 4: Introduction to Recursion (pg. 178-181)
 *
 * Prof.: Abrantes Araújo Silva Filho
 */

#include "genlib.h"
#include <stdio.h>
#include "strlib.h"

/* protótipos de subprogramas */

bool e_palindromo (const string str);         // implementação não eficiente
bool palindromo_p (const string str);         // wrapper para checa_palindromo
static bool checa_palindromo (const string str, const int tam);
                                              // implementação eficiente

/* função main */

int main (void)
{
    printf("%d\n", e_palindromo("level"));
}

/* definição de subprogramas */

/**
 * Predicado: e_palindromo
 * Uso: if (e_palindromo(str)) . . .
 * ---------------------------------
 * Este predicado retorna TRUE se a string é um palíndromo. Esta implementação
 * opera recursivamente devido ao fato de que todas as strings de comprimento
 * 0 ou 1 são palíndromos (os casos simples), e ao fato de que strings maiores
 * apenas serão palíndromos se o primeiro e o último caractere foram iguais e a
 * substring restante (interna) também for um palíndromo.
 */

bool e_palindromo (const string str)
{
    int len;

    len = StringLength(str);
    if (len <= 1)
        return TRUE;
    else
        return (IthChar(str, 0) == IthChar(str, len - 1)
                && e_palindromo(SubString(str, 1, len -2)));
}

/**
 * Predicado: palindromo_p
 * Uso: if (palingromo_p(str)) . . .
 * ---------------------------------
 * Este predicado retorna TRUE se a string str for um palíndromo. Na verdade
 * este predicado é apenas um wrapper para o predicado checa_palindromo.
 */

bool palindromo_p (const string str)
{
    return checa_palindromo(str, StringLength(str));
}

/**
 * Predicado: checa_palindromo
 * Uso: if (checa_palindromo(str, tam)) . . .
 * ------------------------------------------
 * Esta função retorna TRUE se os próximos tam caracteres no array de caracteres
 * na string forem um palíndromo. A implementação opera recursivamente devido ao
 * fato de que todas as strings de comprimento 0 ou 1 são palíndromos (os casos
 * simples), e ao fato de que strings maiores apenas serão palíndromos se o
 * primeiro e o último caractere foram iguais e a substring restante (interna)
 * também for um palíndromo. A nova "substring" começa em str+1 e continua até
 * tam-2 caractere.
 */

static bool checa_palindromo (const string str, const int tam)
{
    if (tam <= 1)
        return TRUE;
    else
        return (str[0] == str[tam - 1]
                && checa_palindromo(str + 1, tam - 2));
}
