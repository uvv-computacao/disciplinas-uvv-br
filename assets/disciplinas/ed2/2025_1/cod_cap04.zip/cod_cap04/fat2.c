/**
 * Arquivo: fat2.c
 * ---------------
 * Demonstra uma implementação recursiva para o cálculo de n!.
 */

#include <stdio.h>

int fat (int n);

int main (void)
{
    printf("5! = %d\n", fat(5));
}

/**
 * Função: fat
 * Uso: n = fat(x)
 * ---------------
 * Esta função retorna o fatorial de um número inteiro x. Caso x < 0 retorna -1
 * para indicar que estamos tentando calcular o fatorial de um número negativo.
 * O tipo de retorno é int.
 */

int fat (int n)
{
    if (n < 0)
        return -1;
    else if (n == 0)
        return 1;
    else
        return n * fat(n - 1);
}

