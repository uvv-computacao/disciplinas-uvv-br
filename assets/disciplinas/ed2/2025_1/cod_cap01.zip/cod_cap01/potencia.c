/**
 * Arquivo: potencia.c
 * Versão : 1.0
 * Data   : 2025-02-11 00:19
 * -------------------------
 * Este programa implementa gera uma tabela comparando os valores das funções
 * n^2 e 2^n.
 *
 * Baseado em: Programming Abstractions in C, de Eric S. Roberts.
 *             Capítulo 1: An Overview of ANSI C (pg. 6-7).
 *
 * Prof.: Abrantes Araújo Silva Filho (Computação Raiz)
 *            www.computacaoraiz.com.br
 *            www.youtube.com.br/computacaoraiz
 *            github.com/computacaoraiz
 *            twitter.com/ComputacaoRaiz
 *            www.linkedin.com/company/computacaoraiz
 *            www.abrantes.pro.br
 *            github.com/abrantesasf
 */

/*** Includes ***/

#include <stdio.h>
#include <stdlib.h>

/*** Constantes Simbólicas ***/

/**
 * Constantes: LIMITE_INFERIOR
 *             LIMITE_SUPERIOR
 * ---------------------------
 * Estas constantes definem os pontos de início e fim da tabela.
 */

#define LIMITE_INFERIOR  0
#define LIMITE_SUPERIOR 12

/*** Declarações de Subprogramas ***/

/**
 * FUNÇÃO: potencia
 * Uso: res = potencia(n, p);
 * --------------------------
 * Esta função recebe dois números inteiros, "n" e "p", e retorna o valor de
 * n^p, ou seja, "n" elevado à "p-ésima" potência. O usuário deve garantir que
 * "n" e "p" não sejam ambos 0 (zero) ao mesmo tempo.
 */

static int potencia (int n, int p);

/*** Função Main: ***/

int main (void)
{
    printf("    |   2 |    N\n");
    printf("  N |  N  |   2\n");
    printf("----+-----+------\n");

    for (int n = LIMITE_INFERIOR; n <= LIMITE_SUPERIOR; n++)
    {
        printf(" %2d | %3d | %4d\n", n,
               potencia(n, 2),
               potencia(2, n));
    }

    return EXIT_SUCCESS;
}

/*** Definições de Subprogramas ***/

/**
 * FUNÇÃO: potencia
 * Uso: res = potencia(n, p);
 * --------------------------
 * Retorna "n" elevado à "p-ésima" potência.
 */

static int potencia (int n, int p)
{
    int resultado = 1;
    for (int i = 0; i < p; i++)
        resultado *= n;
    return resultado;
}
