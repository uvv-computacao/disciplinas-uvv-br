/**
 * Arquivo: adicao.c
 * Versão : 1.0
 * Data   : 2025-02-10 13:11
 * -------------------------
 * Este programa adiciona números fornecidos pelo usuário. O final da entrada
 * dos dados é indicado pelo usuário através de um valor sentinela, que é
 * definido através de uma constante simbólica.
 *
 * Baseado em: Programming Abstractions in C, de Eric S. Roberts.
 *             Capítulo 1: An Overview of C (pg. 37-37).
 *
 * Prof.: Abrantes Araújo Silva Filho (Computação Raiz)
 *            www.computacaoraiz.com.br
 *            www.youtube.com.br/computacaoraiz
 *            github.com/computacaoraiz
 *            twitter.com/ComputacaoRaiz
 *            www.linkedin.com/company/computacaoraiz
 *            www.abrantes.pro.br
 *            github.com/abrantesasf
 */

/*** Includes ***/

#include <CRpaic.h>
#include <stdio.h>
#include <stdlib.h>

/*** Constantes Simbólicas ***/

/**
 * Constante: SENTINELA
 * --------------------
 * Define o valor que será utilizado pelo usuário para indicar o final da
 * entrada de dados.
 */

#define SENTINELA 0

/*** Função Main: ***/

int main (void)
{
    printf("Este programa adiciona uma lista de números.\n");
    printf("Use %d para sinalizar o final da lista.\n", SENTINELA);

    int valor, total;
    total = 0;

    while (true)
    {
        valor = get_int("Informe um número: ");
        if (valor == SENTINELA) break;
        total += valor;
    }

    printf("A soma total é de %d.\n", total);

    return EXIT_SUCCESS;
}
