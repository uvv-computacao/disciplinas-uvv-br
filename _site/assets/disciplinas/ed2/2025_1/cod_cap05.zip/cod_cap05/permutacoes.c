/**
 * Arquivo: permutacoes.c
 * Versão : 1.0
 * Data   : 2024-09-05 16:35
 * -------------------------
 * Este programa implementa uma função recursiva para a geração de permutações
 * de letras em strings, com a restrição de que a string informada deve ser
 * obrigatoriamente um array de char (não pode ser um ponteiro para uma string
 * literal, que é constante e imutável e que, nessa situação, geraria um erro
 * de memória ao tentarmos trocar os caracteres de lugar).
 *
 * Baseado em: Programming Abstractions in C, de Eric S. Roberts.
 *             Capítulo 5: Recursive Procedures (pg. 206-208).
 *
 * Prof.: Abrantes Araújo Silva Filho
 *        Computação Raiz:
 *            www.computacaoraiz.com.br
 *            www.youtube.com.br/computacaoraiz
 *            github.com/computacaoraiz
 *            twitter.com/ComputacaoRaiz
 *            www.linkedin.com/company/computacaoraiz
 *            www.abrantes.pro.br
 */

#include "genlib.h"
#include "simpio.h"
#include "strlib.h"

/* Declarações de Subprogramas: */

void permutar (char str[]);
static void realizar_permutacao (char str[], int k);
static void trocar_letras (char str[], int p1, int p2);

/* Função Main: */

int main (void)
{
    // A string deve ser mutável, por isso deve ser um array de char
    // e não uma string gerada com um string literal (que é imutável):
    char str[] = {'A', 'B', 'C', 'D', '\0'};
    
    printf("Permutações de: %s\n", str);
    permutar(str);
}

/* Definições de Subprogramas: */

/**
 * Procedimento: permutar
 * Uso: permutar("string");
 * ------------------------
 * Este procedimento é um wrapper que recebe uma string str (a rigor recebe um
 * ponteiro para um array de char) e chama o procedimento realizar_permutacao.
 * Como, inicialmente, todas as letras podem ser permutadas, este procedimento
 * utiliza o valor 0 (zero) para a quantidade de letras fixas no começo da
 * string.
 */

void permutar (char str[])
{
    realizar_permutacao(str, 0);
}

/**
 * Procedimento: realizar_permutacao
 * Uso: realizar_permutacao("string", k);
 * --------------------------------------
 * Implementa uma solução recursiva para o problema de encontrar todas as
 * permutações de letras em uma string. Recebe a string cujas letras devem
 * ser permutadas (a rigor recebe um ponteiro para um array de char) e um
 * número inteiro "k" que indica quantas letras, no início da string, devem
 * ser mantidas fixas.
 */

static void realizar_permutacao (char str[], int k)
{
    if (k == StringLength(str))
        printf("%s\n", str);
    else
    {
        for (int i = k; i < StringLength(str); i++)
        {
            trocar_letras(str, k, i);
            realizar_permutacao(str, k + 1);
            trocar_letras(str, k, i);
        }
    }
}

/**
 * Procedimento: trocar_letras
 * Uso: trocar_letras(string, p1, p2);
 * -----------------------------------
 * Procedimento auxiliar que recebe uma string (a rigor um ponteiro para um
 * array de char), e duas posições de caracteres chamadas de p1 e p2, e realiza
 * a troca das letras nas posições recebidas.
 */

static void trocar_letras (char str[], int p1, int p2)
{
    char temp;
    temp = str[p1];
    str[p1] = str[p2];
    str[p2] = temp;
}
