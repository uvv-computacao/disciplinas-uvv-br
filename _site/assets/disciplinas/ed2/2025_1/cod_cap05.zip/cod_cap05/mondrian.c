/**
 * Arquivo: mondrian.c
 * Versão : 1.0
 * Data   : 2024-09-06 18:27
 * -------------------------
 * Este programa cria um desenho com linhas aleatórias no estilo do pintor
 * holandês Piet Mondrian. A figura é gerada recursivamente através da
 * subdivisão da tela em retângulos sucessivamente menores, com linhas
 * horizontais e verticais escolhidas de modo aleatório. ATENÇÃO com o
 * aviso abaixo:
 *
 * A biblioteca gráfica de referência do livro, graphics.h, foi criada há 30
 * anos atrás (1994) e não funciona corretamente com os computadores atuais
 * (2024). Se você tentar rodar esse programa os resultados serão imprevisíveis,
 * variando de congelar completamente seu sistema (e você ser forçado a desligar
 * seu sistema na força, desligando a alimentação), ocorrer outro problema ou,
 * até mesmo, funcionar corretamente. Eu NÃO fiquei debugando o código fonte
 * antigo do autor mas, pelo menos, descobri algumas pistas:
 *
 *     * Os maiores problemas ocorrem quando você utiliza variáveis locais
 *       automáticas, na função Main, para passar essas variáveis como
 *       argumentos. Isso praticamente congelará seu sistema.
 *
 *     * Se você definir as variáveis necessárias da Main como estáticas, tudo
 *       parece funcionar (até onde eu testei).
 *
 * O código que está aqui, com variáveis estáticas, foi testado em um sistema
 * Ubuntu Linux Mate 20.04.6 LTS (Focal Fossa), com GCC 11.4 e GLIBC 2.31, e
 * funciona perfeitamente.
 *
 * Se você quiser compilar e rodar este código em seu sistema, altere a
 * definição da constante simbólica RODAR para 1.
 *
 * Baseado em: Programming Abstractions in C, de Eric S. Roberts.
 *             Capítulo 5: Recursive Procedures (pg. 212-216).
 *
 * Prof.: Abrantes Araújo Silva Filho
 *        Computação Raiz:
 *            www.computacaoraiz.com.br
 *            www.youtube.com.br/computacaoraiz
 *            github.com/computacaoraiz
 *            twitter.com/ComputacaoRaiz
 *            www.linkedin.com/company/computacaoraiz
 *            www.abrantes.pro.br
 */

#include "genlib.h"
#include "graphics.h"
#include "random.h"
#include "simpio.h"

/* Constantes Simbólicas: */

#define RODAR       0       // Roda ou não o programa
#define AREA_MINIMA 0.50    // Área do menor retângulo que será dividido
#define LADO_MINIMO 0.15    // Tamanho mínimo de cada lado da divisória

/* Declarações de Subprogramas: */

static void dividir_tela (double x, double y,
                          double largura, double altura);

/* Função Main: */

int main (void)
{
    // Impede a execução deste programa se RODAR == 0:
    if (!RODAR)
    {
        printf("ANTES de executar este programa, leia\n");
        printf("as considerações sobre os problemas da\n");
        printf("biblioteca \"graphics.h\" no cabeçalho\n");
        printf("do código fonte (mondrian.c).\n");
        return 1;
    }
    
    InitGraphics();
    Randomize();
    dividir_tela(0, 0, GetWindowWidth(), GetWindowHeight());
}

/* Definições de Subprogramas: */

/**
 * Procedimento: dividir_tela
 * Uso: dividir_tela(x, y, largura, altura);
 * -----------------------------------------
 * Este procedimento realiza a decomposição recursiva de uma tela gráfica (um
 * "canvas"). O canto inferior esquerdo da tela é o ponto (x, y), recebidos como
 * argumentos do procedimento. O procedimento inicialmente verifica o caso
 * simples, que verifica se a área da tela retangular é muito pequena para ser
 * dividida novamente (area < AREA_MINIMA). No caso mais simples o procedimento
 * não faz nada. Se a area > AREA_MINIMA, o procedimento decide se a divisão
 * será horizontal ou vertical, escolhendo a maior dimensão. O proceidimento
 * então escolhe uma linha aleatória para fazer a divisão, garantindo que cada
 * lado tenha pelo menos LADO_MINIMO de comprimento. O procedimento então
 * utiliza uma abordagem de dividir para conquistar para subdividir os dois
 * novos retângulos.
 */

static void dividir_tela (double x, double y,
                          double largura, double altura)
{
    double divisoria, area;
    area = largura * altura;

    if (area < AREA_MINIMA)
        ;
    else
    {
        if (largura > altura)
        {
            divisoria = largura * RandomReal(LADO_MINIMO, 1 - LADO_MINIMO);
            MovePen(x + divisoria, y);
            DrawLine(0, altura);
            dividir_tela(x, y, divisoria, altura);
            dividir_tela(x + divisoria, y, largura - divisoria, altura);
        }
        else
        {
            divisoria = altura * RandomReal(LADO_MINIMO, 1 - LADO_MINIMO);
            MovePen(x, y + divisoria);
            DrawLine(largura, 0);
            dividir_tela(x, y, largura, divisoria);
            dividir_tela(x, y + divisoria, largura, altura - divisoria);
        }
    }
}
