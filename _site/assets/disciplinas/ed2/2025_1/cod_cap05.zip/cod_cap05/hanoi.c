/**
 * Arquivo: hanoi.c
 * ----------------
 * Este programa implementa uma solução recursiva para o problema da Torre de
 * Hanoi, criada na década de 1880 pelo matemático francês Edouard Lucas.
 *
 * Baseado em: Programming Abstractions in C, de Eric S. Roberts.
 *             Capítulo 5: Recursive Procedures (pg. 195-206).
 *
 * Prof.: Abrantes Araújo Silva Filho
 *        abrantesasf@pm.me
 */

#include <math.h>
#include "genlib.h"
#include "simpio.h"
#include <stdio.h>

/* Constantes simbólicas: */

#define MINIMO  2    // n.º mínimo de discos
#define MAXIMO 10    // n.º máximo de discos

/* Protótipos de subprogramas: */

void mover_disco (char origem, char destino);
void hanoi (int n, char origem, char destino, char temp);

/* Função Main: */

int main (void)
{
    int n;
    
    do
    {
        printf("Quantos discos a torre tem (2-10)? ");
        n = GetInteger();
    }
    while (n < MINIMO || n > MAXIMO);

    printf("Serão necessários %d passos:\n", (int) pow(2, n) - 1);
    hanoi(n, 'A', 'B', 'C');

    return 0;
}

/**
 * Procedimento: hanoi
 * Uso: hanoi(n, origem, destino, temp);
 * -------------------------------------
 * Este procedimento implementa uma solução recursiva para o problema da Torre
 * de Hanoi. Recebe um número inteiro n de discos, e três caracteres que
 * servirão para nomear as torres de origem, destino e temporária, por exemplo:
 * A = origem; B = destino; C = temporária. Para a impressão do movimento
 * final do disco chama o procedimento mover_disco.
 */

void hanoi (int n, char origem, char destino, char temp)
{
    if (n == 1)
        mover_disco(origem, destino);
    else
    {
        hanoi(n - 1, origem, temp, destino);
        mover_disco(origem, destino);
        hanoi(n - 1, temp, destino, origem);
    }
}

/**
 * Procedimento: mover_disco
 * Uso: mover_disco(inicio, fim);
 * ------------------------------
 * Este procedimento é utilizado para mover um único disco entre duas torres
 * indicadas por "origem" e "destino". O "movimento" é representado por uma
 * instrução DE-PARA que indica qual a torre de origem e qual a torre
 * de destino para o disco.
 */

void mover_disco (char origem, char destino)
{
    printf("    De %c para %c\n", origem, destino);
}
