/**
 * Arquivo: koch.c
 * Versão : 1.0
 * Data   : 2024-09-07 17:56
 * -------------------------
 * Este programa desenha um fractal de Koch, ou seja, um fractal com forma de
 * floco de neve. ATENÇÃO com o aviso abaixo:
 *
 * A biblioteca gráfica de referência do livro, graphics.h, foi criada há 30
 * anos atrás (1994) e não funciona corretamente com os computadores atuais
 * (2024). Se você tentar rodar esse programa os resultados serão imprevisíveis,
 * variando de congelar completamente seu sistema (e você ser forçado a desligar
 * seu sistema na força, desligando a alimentação), ocorrer outro problema ou,
 * até mesmo, funcionar corretamente. Eu NÃO fiquei debugando o código fonte
 * antigo do autor mas, pelo menos, descobri algumas pistas:
 *
 *     * Os maiores problemas ocorrem quando você utiliza variáveis locais
 *       automáticas, na função Main, para passar essas variáveis como
 *       argumentos. Isso praticamente congelará seu sistema.
 *
 *     * Se você definir as variáveis necessárias da Main como estáticas, tudo
 *       parece funcionar (até onde eu testei).
 *
 * O código que está aqui, com variáveis estáticas, foi testado em um sistema
 * Ubuntu Linux Mate 20.04.6 LTS (Focal Fossa), com GCC 11.4 e GLIBC 2.31, e
 * funciona perfeitamente.
 *
 * Se você quiser compilar e rodar este código em seu sistema, altere a
 * definição da constante simbólica RODAR para 1.
 *
 * Baseado em: Programming Abstractions in C, de Eric S. Roberts.
 *             Capítulo 5: Recursive Procedures (pg. 217-222).
 *
 * Prof.: Abrantes Araújo Silva Filho
 *        Computação Raiz:
 *            www.computacaoraiz.com.br
 *            www.youtube.com.br/computacaoraiz
 *            github.com/computacaoraiz
 *            twitter.com/ComputacaoRaiz
 *            www.linkedin.com/company/computacaoraiz
 *            www.abrantes.pro.br
 */

#include "genlib.h"
#include "graphics.h"
#include <math.h>
#include "simpio.h"

/* Constantes Simbólicas: */

#define M_PI 3.14159265358979323846264338327    // Se estamos rigorosamente no
                                                // C padrão, M_PI não é definida
#define RODAR    0                              // Roda ou não o programa
#define TAM_MIN  1.0                            // Tamanho mínimo do fractal
#define TAM_MAX  3.0                            // Tamanho máximo do fractal
#define ORD_MIN  0                              // Ordem mínima do fractal
#define ORD_MAX 10                              // Ordem máxima do fractal

/* Declarações de Subprogramas: */

static void fractal (double tamanho, int ordem);
static void DrawPolarLine (double r, double theta);
static void DrawFractalLine(double tamanho, double theta, int ordem);

/* Função Main: */

int main (void)
{
    // Impede a execução deste programa se RODAR == 0:
    if (!RODAR)
    {
        printf("ANTES de executar este programa, leia\n");
        printf("as considerações sobre os problemas da\n");
        printf("biblioteca \"graphics.h\" no cabeçalho\n");
        printf("do código fonte (koch.c).\n");
        return 1;
    }

    // Solicita dados de tamanho e ordem ao usuário, mantendo essas
    // variáveis como estáticas para evitar problemas com graphics.h:
    static double tamanho = 3.0;
    static int ordem = 4;
    
    do
    {
        printf("Qual o tamanho desejado (%.1f-%.1f): ", TAM_MIN, TAM_MAX);
        tamanho = GetReal();
    }
    while (tamanho < TAM_MIN || tamanho > TAM_MAX);

    do
    {
        printf("Qual a ordem desejada (%d-%d): ", ORD_MIN, ORD_MAX);
        ordem = GetInteger();
    }
    while (ordem < ORD_MIN || ordem > ORD_MAX);

    // Inicializa ambiente gráfico:
    InitGraphics();

    // Cria o fractal desejado:
    fractal(tamanho, ordem);
}

/* Definições de Subprogramas: */

/**
 * Procedimento: fractal
 * Uso: fractal(tamanho, ordem);
 * -----------------------------
 * Este procedimento desenha um fractal de Koch, com formato de floco de neve,
 * centralizado na janela gráfica, com tamanho e ordem recebidos como
 * argumentos.
 */

static void fractal (double tamanho, int ordem)
{
    double x0, y0;
    x0 = GetWindowWidth() / 2.0 - tamanho / 2.0;
    y0 = GetWindowHeight() / 2.0 - sqrt(3.0) * tamanho / 6.0;
    MovePen(x0, y0);
    DrawFractalLine(tamanho, 0, ordem);
    DrawFractalLine(tamanho, 120, ordem);
    DrawFractalLine(tamanho, 240, ordem);
}

/**
 * Procedimento: DrawPolarLine
 * Uso: DrawPolarLine(r, theta);
 * -----------------------------
 * Este procedimento desenha uma linha de comprimento r (um double recebido
 * como argumento) na direção especificada pelo ângulo theta (um double recebido
 * como argumento). Theta é medido em graus no sentido anti-horário, a partir do
 * sentido positivo do eixo x. Os parâmetros r e theta são chamados de
 * coordenadas polares.
 *
 * É necessário o uso da biblioteca math.h para o cálculo do seno (sin) e do
 * cosseno (cos) de um ângulo em radianos. A constante M_PI só será definida
 * por math.h se não estivermos compilando em um padrão C restrito, caso
 * contrário essa constante não é definida e você precisa definir manualmente.
 */

static void DrawPolarLine (double r, double theta)
{
    double radians;
    radians = theta / 180 * M_PI;
    DrawLine(r * cos(radians), r * sin(radians));
}

/**
 * Procedimento: DrawFractalLine
 * Uso: DrawFractalLine(tamanho, theta, ordem);
 * --------------------------------------------
 * Este procedimento desenha uma linha com um determinado tamanaho, em um
 * fractal, iniciando no ponto atual e movendo-se em direção à theta. Se a ordem
 * é 0 (zero), a linha do fractal é apenas uma linha reta. Se a ordem é maior do
 * que zero, a linha é dividida em 4 segmentos de rede, cada uma das quais é uma
 * linha de um fractal de maior ordem. Os 4 segmentos conectam os mesmos pontos
 * extremos, mas incluem uma "ponta" triangular no centro do terceiro segmento.
 */

static void DrawFractalLine(double tamanho, double theta, int ordem)
{
    if (ordem == 0)
        DrawPolarLine(tamanho, theta);
    else
    {
        DrawFractalLine(tamanho/3, theta, ordem - 1);
        DrawFractalLine(tamanho/3, theta - 60, ordem - 1);
        DrawFractalLine(tamanho/3, theta + 60, ordem -1);
        DrawFractalLine(tamanho/3, theta, ordem - 1);
    }
}
