/**
 * Arquivo: teste_grafico.c
 * Versão : 1.0
 * Data   : 2024-09-06 17:23
 * -------------------------
 * Este programa implementa um simples teste da biblioteca gráfica que acompanha
 * o livro de referência de nossa disciplina, desenhando uma forma geométrica
 * que lembra uma janela em arco. ATENÇÃO com o aviso abaixo:
 *
 * A biblioteca gráfica de referência do livro, graphics.h, foi criada há 30
 * anos atrás (1994) e não funciona corretamente com os computadores atuais
 * (2024). Se você tentar rodar esse programa os resultados serão imprevisíveis,
 * variando de congelar completamente seu sistema (e você ser forçado a desligar
 * seu sistema na força, desligando a alimentação), ocorrer outro problema ou,
 * até mesmo, funcionar corretamente. Eu NÃO fiquei debugando o código fonte
 * antigo do autor mas, pelo menos, descobri algumas pistas:
 *
 *     * Os maiores problemas ocorrem quando você utiliza variáveis locais
 *       automáticas, na função Main, para passar essas variáveis como
 *       argumentos. Isso praticamente congelará seu sistema.
 *
 *     * Se você definir as variáveis necessárias da Main como estáticas, tudo
 *       parece funcionar (até onde eu testei).
 *
 * O código que está aqui, com variáveis estáticas, foi testado em um sistema
 * Ubuntu Linux Mate 20.04.6 LTS (Focal Fossa), com GCC 11.4 e GLIBC 2.31, e
 * funciona perfeitamente.
 *
 * Se você quiser compilar e rodar este código em seu sistema, altere a
 * definição da constante simbólica RODAR para 1.
 *
 * Inicialize o programa a partir de um terminal: isso fará com que a janela
 * grpafica seja exibida no monitor de seu computador. Para encerrar o programa
 * você tem duas opções (prefira a opçao 2):
 *
 *    1. Você pode clicar no botão "x", na janela, o que gera um encerramento
 *       forçado do programa e um código de retorno de insucesso ao sistema
 *       operacional; ou
 *
 *    2. Você digita a tecla "enter", no terminal onde o programa foi
 *       inicializado, gerando um encerramento normal e limpo, com um
 *       retorno de sucesso para o sistema operacional.
 *
 * Baseado em: Programming Abstractions in C, de Eric S. Roberts.
 *             Capítulo 5: Recursive Procedures (pg. 209-212).
 *
 * Prof.: Abrantes Araújo Silva Filho
 *        Computação Raiz:
 *            www.computacaoraiz.com.br
 *            www.youtube.com.br/computacaoraiz
 *            github.com/computacaoraiz
 *            twitter.com/ComputacaoRaiz
 *            www.linkedin.com/company/computacaoraiz
 *            www.abrantes.pro.br
 */

#include "genlib.h"
#include "graphics.h"
#include "simpio.h"
#include "strlib.h"

/* Constantes Simbólicas: */

#define RODAR    0        // Roda ou não o programa
#define TAM_MIN  0.25     // Tamanho mínimo do lado para o teste
#define TAM_MAX  2.25     // Tamanho máximo do lado para o teste

/* Função Main: */

int main (void)
{
    // Impede a execução deste programa se RODAR == 0:
    if (!RODAR)
    {
        printf("ANTES de executar este programa, leia\n");
        printf("as considerações sobre os problemas da\n");
        printf("biblioteca \"graphics.h\" no cabeçalho\n");
        printf("do código fonte (teste_grafico.c).\n");
        return 1;
    }

    // Solicita dados do usuário:
    static double tamanho = 0;
    do
    {
        printf("Informe o tamanho do lado (%.2f - %.2f): ", TAM_MIN, TAM_MAX);
        tamanho = GetReal();
    }
    while (tamanho < TAM_MIN || tamanho > TAM_MAX);
        
    // Inicializa a janela gráfica:
    InitGraphics();

    // Desenha uma janela em arco:
    MovePen(2.0, 0.5);
    DrawLine(tamanho, 0.0);
    DrawLine(0.0, tamanho);
    DrawArc(tamanho/2, 0, 180);
    DrawLine(0.0, -tamanho);
}

