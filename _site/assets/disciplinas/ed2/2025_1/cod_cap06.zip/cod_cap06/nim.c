/**
 * Arquivo: nim.c
 * Versão : 1.0
 * Data   : 2024-09-13 21:30
 * -------------------------
 * Este programa simula uma variante simples de um jogo de nim. Nesta versão o
 * jogo se inicia com uma pilha de 13 moedas em uma mesa. Os jogadores então se
 * revezam retirando 1, 2 ou 3 moedas da pilha. O jogador que for forçado a
 * pegar a última moeda perde. Nesta simulação o jogador humano irá competir com
 * o computador. Note que, nas condições apresentadas, o computador sempre
 * vencerá. Para dar alguma chance para o jogador humano, aumente o número de
 * moedas. Você também pode alterar os parâmetros das constantes simbólicas para
 * criar variações do jogo que podem ser mais fáceis para o jogador humano.
 *
 * Baseado em: Programming Abstractions in C, de Eric S. Roberts.
 *             Capítulo 6: Backtracking Algorithms (pg. 245-253).
 *
 * Prof.: Abrantes Araújo Silva Filho
 *        Computação Raiz:
 *            www.computacaoraiz.com.br
 *            www.youtube.com.br/computacaoraiz
 *            github.com/computacaoraiz
 *            twitter.com/ComputacaoRaiz
 *            www.linkedin.com/company/computacaoraiz
 *            www.abrantes.pro.br
 *            github.com/abrantesasf
 */

#include "genlib.h"
#include "simpio.h"
#include "strlib.h"

/**
 * Constantes Simbólicas:
 * ----------------------
 * QTD_MOEDAS        -- quantidade inicial de moedas
 * RETIRADA_MINIMA   -- número mínimo de moedas que o jogador pode retirar
 * RETIRADA_MAXIMA   -- número máximo de moedas que o jogador pode retirar
 * SEM_BOM_MOVIMENTO -- sentinela que india que não há mais bons movimentos
 */

#define QTD_MOEDAS 13          // o computador sempre vence com 13 moedas
#define RETIRADA_MINIMA 1
#define RETIRADA_MAXIMA 3
#define SEM_BOM_MOVIMENTO -1

/**
 * Tipo: jogadorT
 * --------------
 * Enumeração que fará a distinção entre as jogadas humanas e as jogadas do
 * computador.
 */

enum en_jogadorT
{
    Humano,
    Computador
};

typedef enum en_jogadorT jogadorT;

/* Declarações de Subprogramas: */

static void dar_instrucoes (void);
static void anunciar_vencedor (int moedas, jogadorT jogador);
static int obter_movimento_do_jogador (int moedas);
static bool movimento_e_valido (int retirar, int moedas);
static int escolher_movimento_computador (int moedas);
static int achar_bom_movimento (int moedas);
static bool e_posicao_ruim (int moedas);

/**
 * Função: Main
 * ------------
 * Executa o jogo de nim. Nesta implementação, o jogador humano sempre joga em
 * primeiro lugar.
 */

int main (void)
{
    int moedas, retirar;
    jogadorT jogador;

    dar_instrucoes();
    moedas = QTD_MOEDAS;
    jogador = Humano;
    while (moedas > 1)
    {
        printf("Existem %d moedas na pilha.\n", moedas);
        switch (jogador)
        {
        case Humano:
            retirar = obter_movimento_do_jogador(moedas);
            jogador = Computador;
            break;
        case Computador:
            retirar = escolher_movimento_computador(moedas);
            printf("Eu retirarei %d moedas.\n", retirar);
            jogador = Humano;
            break;
        }
        moedas -= retirar;
    }
    anunciar_vencedor(moedas, jogador);
}

/* Definições de Subprogramas: */

/**
 * Procedimento: dar_instrucoes
 * Uso: dar_instrucoes( );
 * -----------------------
 * Este procedimento explica as regras do jogo para o usuário.
 */

static void dar_instrucoes (void)
{
    printf("Olá! Bem-vindo ao jogo de nim.\n");
    printf("Neste jogo começaremos com uma pilha de\n");
    printf("%d moedas na mesa.\n", QTD_MOEDAS);
    printf("A cada jogada você e eu retiraremos,\n");
    printf("de forma alternada, entre %d e %d modedas\n",
           RETIRADA_MINIMA, RETIRADA_MAXIMA);
    printf("da mesa. O jogador que for obrigado a\n");
    printf("retirar a última moeda perde.\n");
    printf("\n");
}

/**
 * Procedimento: anunciar_vencedor
 * Uso: anunciar_vencedor(moedas, jogador);
 * ----------------------------------------
 * Este procedimento anuncia o resultado final do jogo.
 */

static void anunciar_vencedor (int moedas, jogadorT jogador)
{
    if (moedas == 0)
        printf("Você retirou a última moeda. Você perdeu!\n");
    else
    {
        printf("Só há 1 moeda restante.\n");
        switch (jogador)
        {
        case Humano: printf("Eu ganhei!\n"); break;
        case Computador: printf("Eu perdi!\n"); break;
        }
    }
}

/**
 * Função: obter_movimento_do_jogador
 * Uso: retirar = obter_movimento_do_jogador(moedas);
 * --------------------------------------------------
 * Esta função é a responsável pela jogada do Humano. Ela recebe como argumento
 * a quantidade de moedas restantes na mesma, e retorna o número de moedas que o
 * jogador humano removerá da pilha. A função verifica se o movimento é válido,
 * dando várias tentativas ao jogador para que ele informe um número válido.
 */

static int obter_movimento_do_jogador (int moedas)
{
    int retirar, limite;

    while (TRUE)
    {
        printf("Quantas moedas você irá retirar? ");
        retirar = GetInteger();
        if (movimento_e_valido(retirar, moedas)) break;
        limite = (moedas < RETIRADA_MAXIMA) ? moedas : RETIRADA_MAXIMA;
        printf("Movimento inválido! Por favor, escolha um número entre\n");
        printf("%d e %d moedas.\n", RETIRADA_MINIMA, limite);
        printf("Existem %d moedas na pilha.\n", moedas);
    }

    return retirar;
}

/**
 * Predicado: movimento_e_valido
 * Uso: if (movimento_e_valido(retirar, moedas)) . . .
 * ---------------------------------------------------
 * Este predicado retorna TRUE se for válido remover a quantidade de moedas
 * indicada pelo argumento "retirar" da quantidade de moedas indicada pelo
 * argumento "moedas".
 */

static bool movimento_e_valido (int retirar, int moedas)
{
    return (retirar > 0 && retirar <= RETIRADA_MAXIMA && retirar <= moedas);
}

/**
 * Função: escolher_movimento_computador
 * Uso: retirar = escolher_movimento_computador (moedas);
 * ------------------------------------------------------
 * Esta função descobre qual o melhor movimento para o computador e retorna o
 * número de moedas que o computador retirará da pilha. Inicialmente a função
 * chama a "achar_bom_movimento" para verificar se algum movimento vencedor
 * existe. Se nenhum movimento vencedor existe, o programa só retira 1 única
 * moeda para dar ao jogador humano mais chances dele cometer um erro.
 */

static int escolher_movimento_computador (int moedas)
{
    int retirar;

    retirar = achar_bom_movimento(moedas);
    if (retirar == SEM_BOM_MOVIMENTO)
        retirar = 1;
    return retirar;
}

/**
 * Função: achar_bom_movimento
 * Uso: retirar = achar_bom_movimento(moedas);
 * -------------------------------------------
 * Esta função busca um movimento vencedor, dado o número especificado de moedas
 * através do argumento de mesmo nome. Se existir um movimento vencedor nessa
 * posição, a função retorna esse valor; se não houver um movimento vencedor, a
 * função retorna a constante SEM_BOM_MOVIMENTO. Esta função depende do insight
 * recursivo de que:
 *     - Um bom movimento é aquele que deixe o oponente em uma má posição;
 *     - Uma má posição é aquela onde não existem bons movimentos.
 */

static int achar_bom_movimento (int moedas)
{
    int retirar;

    for (retirar = RETIRADA_MINIMA; retirar <= RETIRADA_MAXIMA; retirar++)
    {
        if (e_posicao_ruim(moedas - retirar))
            return retirar;
    }
    return SEM_BOM_MOVIMENTO;
}

/**
 * Predicado: e_posicao_ruim
 * Uso: if (e_posicao_ruim(moedas)) . . .
 * --------------------------------------
 * Este predicado retorna TRUE se a quantidade de moedas indicada pelo argumento
 * for uma má posição. Uma má posição é aquela na qual não há bons movimentos
 * possíveis. Ser deixado com 1 única moeda também é, claramente, uma má posição
 * e representa o caso simples da recursão.
 */

static bool e_posicao_ruim (int moedas)
{
    if (moedas == 1)
        return TRUE;
    return (achar_bom_movimento(moedas) == SEM_BOM_MOVIMENTO);
}
