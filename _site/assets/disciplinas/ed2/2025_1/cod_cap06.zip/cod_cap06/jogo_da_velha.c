/**
 * Arquivo: jogo_da_velha.c
 * Versão : 1.0
 * Data   : 2024-09-15 01:04
 * -------------------------
 * Este programa joga uma partida de "Jogo da Velha" (tic-tac-toe) com o
 * usuário. O programa está projetado para enfatizar a separação entre os
 * aspectos do código que são comuns à todos os jogos de estratégia entre
 * dois jogadores e os aspectos que são específicos ao "Jogo da Velha". O
 * melhor que um jogador pode fazer contra o computador é empatar o jogo.
 *
 * Baseado em: Programming Abstractions in C, de Eric S. Roberts.
 *             Capítulo 6: Backtracking Algorithms (pg. 248-271).
 *
 * Prof.: Abrantes Araújo Silva Filho
 *        Computação Raiz:
 *            www.computacaoraiz.com.br
 *            www.youtube.com.br/computacaoraiz
 *            github.com/computacaoraiz
 *            twitter.com/ComputacaoRaiz
 *            www.linkedin.com/company/computacaoraiz
 *            www.abrantes.pro.br
 *            github.com/abrantesasf
 */

#include "genlib.h"
#include "simpio.h"
#include "strlib.h"

/**
 * Constantes simbólicas:
 * ----------------------
 * Estas constantes definem um sistema de pontuação para as posições do jogo.
 * A pontuação é um inteiro centralizado ao redor do zero. O zero funciona como
 * uma pontuação neutra e é identificado pela constante POSICAO_NEUTRA; notas
 * acima de 0 são boas para o jogador atual, e notas abaixo de 0 são boas para o
 * oponente. As constantes POSICAO_VENCEDORA e POSICAO_PERDEDORA são opostas e
 * indicam uma posição que é uma vitória ou derrota certa, respectivamente. Em
 * um jogo cuja análise estiver completa, nenhum valor intermidário jamais
 * ocorrerá. Se a árvore completa for muito grande para ser analisada, a função
 * "avaliar_posicao" retornará um inteiro entre esses dois extremos.
 */

#define POSICAO_NEUTRA 0
#define POSICAO_VENCEDORA 1000
#define POSICAO_PERDEDORA (-POSICAO_VENCEDORA)

/**
 * Constante simbólica: MAX_MOVIMENTOS
 * -----------------------------------
 * Esta constante indica o número máximo de movimentos válidos disponíveis na
 * jogada da vez, e é utilizada para alocar o array para a lista de movimentos
 * válidos. Esta constante deve ser alterada de acordo com o jogo a ser
 * implementado. Para o "Jogo da Velha", nunca haverão mais do que 9 movimentos
 * possíveis.
 */

#define MAX_MOVIMENTOS 9

/**
 * Constante simbólica: PROFUNDIDADE_MAX
 * -------------------------------------
 * Esta constante indica a profundidade máxima que a busca recursiva está
 * autorizada a executar. O uso de um valor grande nesta constante garante
 * que a análise seja executada até o final do jogo. Em contrapartida, se
 * o jogo for extremamente complexo (como xadrez, por exemplo), um valor alto
 * nesta constante fará com que a escolha do movimento demore muito a ser feita
 * devido à busca recursiva que será muito grande.
 */

#define PROFUNDIDADE_MAX 10000

/**
 * Constante simbólica: PRIMEIRO_JOGADOR
 * -------------------------------------
 * Esta constante indica se o Humano ou se o Computador fará o primeiro
 * movimento, e deve ser um dos valores possíveis para o tipo jogadorT (ver
 * a seguir). Nesta implementação o Computador fará o primeiro movimento.
 * Você pode alterar aqui para o jogador ser o Humano ou pode criar uma função
 * que retorna aleatoriamente o primeiro jogador.
 */

#define PRIMEIRO_JOGADOR Computador

/**
 * Tipo: jogadorT
 * --------------
 * Este tipo é utilizado para distinguir um jogador Humano do jogador que é o
 * Computador, e também para manter um controle de qual é o jogador da vez.
 */

enum en_jogadorT { Humano, Computador };

typedef enum en_jogadorT jogadorT;

/**
 * Tipo: movimentoT
 * ----------------
 * Para qualquer jogo em particular, o tipo movimentoT deve ser capaz de manter
 * todas as informações necessárias para descrever um movimento. Para o "Jogo da
 * Velha" um movimento é simplesmente um número inteiro identificando o número
 * de um dos 9 quadrados do tabuleiro do jogo (ver o tipo estadoT).
 */

typedef int movimentoT;

/**
 * Tipo: estadoT
 * -------------
 * Para qualquer jogo, a estrutura estadoT registra o estado atual do jogo. Para
 * o "Jogo da Velha" o principal componente do estado é o "tabuleiro", que é um
 * array de caracteres usando 'X' para o primeiro jogador, 'O' para o segundo
 * jogador, e ' ' para quadrados vazios. Embora o tabuleiro seja logicamente uma
 * estrutura bidimensional, ele é armazenado como um array linear de tal forma
 * que seus índices "batem" com os números utilizados para se referir aos
 * quadrados do tabuleiro, da seguinte maneira:
 *
 *          1 | 2 | 3
 *         ---+---+---
 *          4 | 5 | 6
 *         ---+---+---
 *          7 | 8 | 9
 *
 * Note que o índice 0 (zero) não é utilizado, o que exige a alocação de um
 * elemento extra.
 *
 * Além do array que representa o tabuleiro, o código armazena o valor do
 * jogadorT para indicar de quem é a vez de jogar. Nesta implementação o estadoT
 * também contém o número total de movimentos (o número de total de marcações de
 * 'X' ou 'O', as jogadas que os jogadores já fizeram) para que outras funções
 * possam checar essa informação sem ter que contar o número de quadrados
 * ocupados.
 *
 * ATENÇÃO: note que estadoT é implementado como um PONTEIRO para uma estrutra,
 * a struct st_estadoT. Essa estrutura é a única a manter o estado do jogo.
 */

struct st_estadoT
{
    char tabuleiro[3 * 3 + 1];
    jogadorT jogador;
    int numero_jogadas_feitas;
};

typedef struct st_estadoT *estadoT;

/**
 * Variáveis globais privadas: linhas_vencedoras, num_linhas_vencedoras
 * --------------------------------------------------------------------
 * A variável "linhas_vencedoras" é um array bidimensional que contém os índices
 * das células em cada uma das combinações vencedoras. Embora seja fácil para o
 * programa calcular esses valores durante o próprio jogo, armazenar essas
 * combinações melhorará o desempenho do jogo.
 *
 * A variável "num_linhas_vencedoras" indica quantas linhas correspondem à
 * posições vencedoras no "Jogo da Velha".
 */

static int linhas_vencedoras[][3] = {
    { 1, 2, 3 },
    { 4, 5, 6 },
    { 7, 8, 9 },
    { 1, 4, 7 },
    { 2, 5, 8 },
    { 3, 6, 9 },
    { 1, 5, 9 },
    { 3, 5, 7 }
};

static int num_linhas_vencedoras =
    sizeof linhas_vencedoras / sizeof linhas_vencedoras[0];

/* Declarações de Subprogramas: */

static movimentoT encontrar_melhor_movimento (estadoT estado, int profundidade,
                                              int *ptr_pontuacao);
static int avaliar_posicao (estadoT estado, int profundidade);
static estadoT novo_jogo (void);
static void mostrar_jogo (estadoT estado);
static void mostrar_movimento (movimentoT movimento);
static void dar_instrucoes (void);
static char marca_do_jogador (jogadorT jogador);
static movimentoT obter_movimento_do_jogador (estadoT estado);
static bool movimento_e_valido (movimentoT movimento, estadoT estado);
static movimentoT escolher_movimento_do_computador (estadoT estado);
static int gerar_lista_de_movimentos (estadoT estado,
                                      movimentoT arr_movimentos[]);
static void fazer_movimento (estadoT estado, movimentoT movimento);
static void desfazer_movimento (estadoT estado, movimentoT movimento);
static void anunciar_resultado (estadoT estado);
static bool jogo_terminou (estadoT estado);
static int avaliar_posicao_estatica (estadoT estado);
static bool verifica_vitoria (estadoT estado, jogadorT jogador);
static jogadorT vez_de_quem (estadoT estado);
static jogadorT oponente (jogadorT jogador);

/**
 * Função: MAIN
 * ------------
 * Este programa "main", juntamente com as funções "encontrar_melhor_movimento"
 * e "avaliar_posicao", são funções com projeto geral e podem ser utilizadas na
 * maioria dos jogos de estratégia que envolvem 2 jogadores. Os detalhes
 * específicos do "Jogo da Velha" não aparecem nessas funções pois estão
 * encapsulados nas estruturas de dados estadoT e movimentoT, bem como diversos
 * outros subprogramas subsidiários.
 */

int main (void)
{
    estadoT estado;
    movimentoT movimento;

    dar_instrucoes();
    estado = novo_jogo();
    while (!jogo_terminou(estado))
    {
        mostrar_jogo(estado);
        switch (vez_de_quem(estado))
        {
        case Humano:
            movimento = obter_movimento_do_jogador(estado);
            break;
        case Computador:
            movimento = escolher_movimento_do_computador(estado);
            mostrar_movimento(movimento);
            break;
        }
        fazer_movimento(estado, movimento);
    }
    anunciar_resultado(estado);
}

/* Definições de Subprogramas: */

/**
 * Função: encontrar_melhor_movimento
 * Uso: movimento =
 *          encontrar_melhor_movimento(estado, profundidade, ptr_pontuacao);
 * -------------------------------------------------------------------------
 * Esta função encontra o melhor movimento para o jogador da vez, dado o estado
 * específico do jogo. O parâmetro "profundidade" e a constante PROFUNDIDADE_MAX
 * são utilizados para limitar a profundidade da busca recursiva para o caso de
 * jogos que são muito difíceis de analisar completamente. A função retorna o
 * melhor movimento e armazena a pontuação desse movimento na variável inteira
 * apontada pelo ponteiro ptr_pontuacao.
 */

static movimentoT encontrar_melhor_movimento (estadoT estado, int profundidade,
                                              int *ptr_pontuacao)
{
    movimentoT arr_movimentos[MAX_MOVIMENTOS], movimento, melhor_movimento;
    int i, n_movimentos, pontuacao, pontuacao_minima;

    n_movimentos = gerar_lista_de_movimentos(estado, arr_movimentos);
    if (n_movimentos == 0) Error("Nenhum movimento disponível");
    pontuacao_minima = POSICAO_VENCEDORA + 1;
    for (i = 0; i < n_movimentos && pontuacao_minima != POSICAO_PERDEDORA; i++)
    {
        movimento = arr_movimentos[i];
        fazer_movimento(estado, movimento);
        pontuacao = avaliar_posicao(estado, profundidade + 1);
        if (pontuacao < pontuacao_minima)
        {
            melhor_movimento = movimento;
            pontuacao_minima = pontuacao;
        }
        desfazer_movimento(estado, movimento);
    }
    *ptr_pontuacao = -pontuacao_minima;
    return melhor_movimento;
}

/**
 * Função: avaliar_posicao
 * Uso: avaliacao = avaliar_posicao(estado, profundidade);
 * -------------------------------------------------------
 * Esta função avalia uma posição encontrando a pontuação do melhor movimento
 * naquela posição. O parâmetro profundidade e a constante PROFUNDIDADE_MAX
 * são usadas para limitar a profundidade da busca recursiva.
 */

static int avaliar_posicao (estadoT estado, int profundidade)
{
    int pontuacao;

    if (jogo_terminou(estado) || profundidade >= PROFUNDIDADE_MAX)
        return avaliar_posicao_estatica(estado);

    (void) encontrar_melhor_movimento(estado, profundidade, &pontuacao);
    return pontuacao;
}

/**
 * Função: novo_jogo
 * Uso: estado = novo_jogo( );
 * ---------------------------
 * Esta função inicia um novo jogo e retorna o estadoT que foi inicializado
 * para ser a configuração inicial do jogo.
 */

static estadoT novo_jogo (void)
{
    estadoT estado;

    estado = New(estadoT);
    for (int i = 1; i <= 9; i++)
        estado->tabuleiro[i] = ' ';
    estado->jogador = PRIMEIRO_JOGADOR;
    estado->numero_jogadas_feitas = 0;
    return estado;
}

/**
 * Procedimento: mostrar_jogo
 * Uso: mostrar_jogo(estado);
 * --------------------------
 * Este procedimento exibe o estado atual do jogo.
 */

static void mostrar_jogo (estadoT estado)
{
    int linha, coluna;

    if (jogo_terminou(estado))
        printf("\nA posição final é a seguinte:\n\n");
    else
        printf("\nA posição atual é a seguinte:\n\n");

    for (linha = 0; linha < 3; linha++)
    {
        if (linha != 0)
            printf("---+---+---\n");
        for (coluna = 0; coluna < 3; coluna++)
        {
            if (coluna != 0)
                printf("|");
            printf(" %c ", estado->tabuleiro[linha * 3 + coluna + 1]);
        }
        printf("\n");
    }
    printf("\n");
}

/**
 * Procedimento: mostrar_movimento
 * Uso mostrar_movimento(estado);
 * -------------------------------
 * Este procedimento mostra o movimento do computador.
 */

static void mostrar_movimento (movimentoT movimento)
{
    printf("Eu irei marcar o quadrado %d.\n", movimento);
}

/**
 * Procedimento: dar_instrucoes
 * Uso: dar_instrucoes( );
 * ----------------------------
 * Este procedimento mostra as instruções do jogo para o jogador.
 */

static void dar_instrucoes (void)
{
    printf("Bem-vindo ao \"Jogo da Velha\". O objetivo do jogo\n");
    printf("é marcar 3 símbolos em uma linha reta, horizontal,\n");
    printf("vertical ou diagonal. Você será o %c ", marca_do_jogador(Humano));
    printf("e eu serei o %c.\n", marca_do_jogador(Computador));
}

/**
 * Função: marca_do_jogador
 * Uso: marca = marca_do_jogado(jogador);
 * --------------------------------------
 * Esta função retorna a marca utilizada no tabuleiro para indicar um jogador
 * específico. Por convenção o primeiro jogador é sempre o X, então a marca
 * utilizada por cada um depende de quem faz a primeira jogada.
 */

static char marca_do_jogador (jogadorT jogador)
{
    if (jogador == PRIMEIRO_JOGADOR)
        return 'X';
    else
        return 'O';
}

/**
 * Função: obter_movimento_do_jogador
 * Uso: movimento = obter_movimento_do_jogador(estado);
 * ----------------------------------------------------
 * Esta função permite que o usuário (o jogador) informe um movimento e retorna
 * o número do quadrado escolhido. Se o usuário especificar um movimento
 * inválido, a função dá novas oportunidades para o usuário informar um outro
 * movimento que seja válido.
 */

static movimentoT obter_movimento_do_jogador (estadoT estado)
{
    movimentoT movimento;

    printf("Sua vez de jogar.\n");
    while (TRUE)
    {
        printf("Que quadrado você vai marcar? ");
        movimento = GetInteger();
        if (movimento_e_valido(movimento, estado)) break;
        printf("Essa jogada não é válida. Tente novamente.\n");
    }
    return movimento;
}

/**
 * Predicado: movimento_e_valido
 * Uso: if (movimento_e_valido(movimento)) . . .
 * ---------------------------------------------
 * Este predicado retorna TRUE se o movimento especificado é válido no estado
 * atual do jogo.
 */

static bool movimento_e_valido (movimentoT movimento, estadoT estado)
{
    return (movimento >= 1 && movimento <= 9
            && estado->tabuleiro[movimento] == ' ');
}

/**
 * Função: escolher_movimento_do_computador
 * Uso: movimento = escolher_movimento_do_computador(estado);
 * ----------------------------------------------------------
 * Esta função escolher o movimento do computador e funciona principalmente como
 * um wrapper para a função encontrar_melhor_movimento. Esta função também torna
 * possível mostrar qualquer mensagem específica do jogo que precisa aparecer
 * no início da vez do computador. O valor retornado pela função
 * escolher_melhor_movimento é simplesmente descartado.
 */

static movimentoT escolher_movimento_do_computador (estadoT estado)
{
    int pontuacao;

    printf("Minha vez de jogar.\n");
    return (encontrar_melhor_movimento(estado, 0, &pontuacao));
}

/**
 * Função: gerar_lista_de_movimentos
 * Uso: n = gerar_lista_de_movimentos(estado, arr_movimentos);
 * -----------------------------------------------------------
 * Esta função gera uma lista dos movimentos legais disponíveis em um
 * determinado estado. A lista de movimentos é retornada no array movimentos,
 * que deve ser alocado pelo cliente. A função retorna o número de movimentos
 * válidos.
 */

static int gerar_lista_de_movimentos (estadoT estado,
                                      movimentoT arr_movimentos[])
{
    int n_movimentos = 0;

    for (int i = 1; i <= 9; i++)
    {
        if (estado->tabuleiro[i] == ' ')
            arr_movimentos[n_movimentos++] = (movimentoT) i;
    }
    return n_movimentos;
}

/**
 * Procedimento: fazer_movimento
 * Uso: fazer_movimento(estado, movimento);
 * ----------------------------------------
 * Este procedimento troca o estado do jogo fazendo o movimento indicado.
 */

static void fazer_movimento (estadoT estado, movimentoT movimento)
{
    estado->tabuleiro[movimento] = marca_do_jogador(estado->jogador);
    estado->jogador = oponente(estado->jogador);
    estado->numero_jogadas_feitas++;
}

/**
 * Procedimento: desfazer_movimento
 * Uso: desfazer_movimento(estado, movimento);
 * -------------------------------------------
 * Este procedimento troca o estado do jogo desfazendo o movimento indicado.
 */

static void desfazer_movimento (estadoT estado, movimentoT movimento)
{
    estado->tabuleiro[movimento] = ' ';
    estado->jogador = oponente(estado->jogador);
    estado->numero_jogadas_feitas--;
}

/**
 * Procedimento: anunciar_resultado
 * Uso: anunciar_resultado(estado);
 * --------------------------------
 * Este procedimento anuncia o resultado final do jogo.
 */

static void anunciar_resultado (estadoT estado)
{
    mostrar_jogo(estado);
    if (verifica_vitoria(estado, Humano))
        printf("Você ganhou!\n");
    else if (verifica_vitoria(estado, Computador))
        printf("Eu ganhei!\n");
    else
        printf("Deu velha!\n");
}

/**
 * Predicado: jogo_terminou
 * Uso: if (jogo_terminou(estado)) . . .
 * -------------------------------------
 * Este predicado retorna TRUE se o jogo acabou.
 */

static bool jogo_terminou (estadoT estado)
{
    return (estado->numero_jogadas_feitas == 9
            || verifica_vitoria(estado, estado->jogador)
            || verifica_vitoria(estado, oponente(estado->jogador)));
}

/**
 * Função: avaliar_posicao_estatica
 * Uso: avaliacao = avaliar_posicao_estatica(estado);
 * --------------------------------------------------
 * Esta função retorna a avaliação de uma posição sem olhar mais para frente na
 * árvore de recursão do jogo. Embora essa função duplique muito do
 * processamento do predicado jogo_terminou e, assim, introduza um pouco de
 * ineficiência em runtime, ela torna o algoritmo um pouco mais fácil de ser
 * seguido e compreendido.
 */

static int avaliar_posicao_estatica (estadoT estado)
{
    if (verifica_vitoria(estado, estado->jogador))
        return POSICAO_VENCEDORA;
    if (verifica_vitoria(estado, oponente(estado->jogador)))
        return POSICAO_PERDEDORA;
    return POSICAO_NEUTRA;
}

/**
 * Predicado: verifica_vitoria
 * Uso: if (verifica_vitoria(estado, jogador)) . . .
 * -------------------------------------------------
 * Este predicado retorna TRUE se o jogador especificado ganhou o jogo. A
 * verificação do número de jogadas aumenta a eficiência pois nenhum jogador
 * pode vencer o jogo até o quinto movimento.
 */

static bool verifica_vitoria (estadoT estado, jogadorT jogador)
{
    char marca;

    if (estado->numero_jogadas_feitas < 5) return FALSE;
    marca = marca_do_jogador(jogador);
    for (int i = 0; i < num_linhas_vencedoras; i++)
    {
        if (marca == estado->tabuleiro[linhas_vencedoras[i][0]]
                && marca == estado->tabuleiro[linhas_vencedoras[i][1]]
                && marca == estado->tabuleiro[linhas_vencedoras[i][2]])
            return TRUE;
    }
    return FALSE;
}

/**
 * Função: vez_de_quem
 * Uso: jogador = vez_de_quem(estado);
 * -----------------------------------
 * Eta função retorna de quem é a vez de jogar, dado o estado atual do jogo.
 */

static jogadorT vez_de_quem (estadoT estado)
{
    return estado->jogador;
}

/**
 * Função: oponente
 * Uso: jogador = oponente(estado);
 * --------------------------------
 * Esta função reorna o jogadorT correspondente ao oponente do jogador
 * especificado.
 */

static jogadorT oponente (jogadorT jogador)
{
    jogadorT oponente;
    
    switch (jogador)
    {
    case Humano:
        oponente = Computador;
        break;
    case Computador:
        oponente = Humano;
        break;
    }
    return oponente;
}
