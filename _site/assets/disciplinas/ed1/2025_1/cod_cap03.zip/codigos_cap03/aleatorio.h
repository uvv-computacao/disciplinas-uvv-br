/**
 * Arquivo: aleatorio.h
 * --------------------
 * Esta interface fornece diversos subprogramas para auxiliar a geração de
 * números pseudo-aleatórios.
 */

#ifndef _ALEATORIO_H
#define _ALEATORIO_H

#include <stdbool.h>

/**
 * Função: inteiro_aleatorio
 * Uso: n = inteiro_aleatorio(min, max);
 * -------------------------------------
 * Esta função retorna um número inteiro aleatório no intervalo FECHADO
 * [min, max], significando que o resultado é sempre maior do que ou igual à
 * "min" e menor do que ou igual à "max".
 */

int inteiro_aleatorio (int min, int max);

/**
 * Função: double_aleatorio
 * Uso: d = double_aleatorio(min, max);
 * ------------------------------------
 * Esta função retorna um número double aleatório no intervalo SEMI-ABERTO À
 * DIREITA [min, max), significando que o resultado seja sempre maior do que ou
 * iqual à "min", mas estritamente menor do que "max".
 */

double double_aleatorio (double min, double max);

/**
 * Predicado: ao_acaso
 * Uso: if (ao_acaso(p)) ...
 * -------------------------
 * Este predicado tem o objetivo de simular eventos aleatórios que ocorrem com
 * uma determinada probabilidade fixa. Ele retorna "true" com probabilidade
 * indicada por "p", que deve ser um double entre 0.0 (nunca) e 1.0 (sempre).
 * Por exemplo: chamar o predicado ao_acaso(0.30) returna "true" em 30% das
 * vezes.
 */

bool ao_acaso (double p);

/**
 * Procedimento: randomizar
 * Uso: randomizar( );
 * -------------------
 * Este procedimento inicializa o gerador de números pseudo-aleatórios para que
 * seus resultados sejam imprevisíveis. Se este procedimento não for chamado, os
 * outros subprogramas retornarão sempre os mesmos valores.
 */

void randomizar (void);

#endif
