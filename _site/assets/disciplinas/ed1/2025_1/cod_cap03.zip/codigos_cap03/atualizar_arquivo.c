/**
 * Arquivo: atualizar_arquivo.c
 * Versão : 1.0
 * Data   : 2025-03-09 19:03
 * ----------------------------
 * Este programa atualiza um arquivo de entrada, removendo todos os comentários
 * de bloco. Isso é feito através da criação de um arquivo temporário.
 */

/*** Includes ***/

#include <CRpaic.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

/*** Declarações de Subprogramas ***/

/**
 * Procedimento: copiar_removendo_comentarios
 * Uso: copiar_removendo_comentario(entrada, saida);
 * -------------------------------------------------
 * Este procedimento faz a copia do arquivo de "entrada" para o arquivo de
 * "saida", removendo todos os comentários de bloco. Recebe dois ponteiros para
 * arquivos, que devem ser ponteiros válidos (o usuário é responsável de passar
 * ponteiros de arquivos válidos).
 */

void copiar_removendo_comentarios (FILE *entrada, FILE *saida);

/*** Função Main: ***/

int main (void)
{
    FILE *entrada, *saida;

    // Cria nome de arquivo temporário (obs.: esta NÃO É A MELHOR PRÁTICA pois
    // cria condições de corrida; o melhor seria usar mkstemp, mas isso fica
    // para uma outra aula mais avançada)
    string arq_temp = "arquivoTemporario";

    printf("Este programa remove comentários de um arquivo.\n");
    string arquivo;
    while (true)
    {
        arquivo = get_string("Arquivo: ");
        entrada = fopen(arquivo, "r");
        if (!entrada)
            printf("Arquivo %s não encontrado. Tente novamente.\n", arquivo);
        else
            break;
    }

    saida = fopen(arq_temp, "w");
    if (!saida)
    {
        fprintf(stderr, "Impossível abrir a saída.\n");
        fclose(entrada);
        return EXIT_FAILURE;
    }

    copiar_removendo_comentarios(entrada, saida);

    fclose(entrada);
    fclose(saida);

    // Remove arquivo original e altera o nome temporário para
    // o original ("recriando" o arquivo):
    if (remove(arquivo) != 0 || rename(arq_temp, arquivo) != 0)
    {
        fprintf(stderr, "Não foi possível renomear o arquivo temporário.\n");
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}

/*** Definições de Subprogramas ***/

/**
 * Procedimento: copiar_removendo_comentarios
 * Uso: copiar_removendo_comentario(entrada, saida);
 * -------------------------------------------------
 */

void copiar_removendo_comentarios (FILE *entrada, FILE *saida)
{
    int c, prox_c;
    bool comentario = false;

    while ((c = getc(entrada)) != EOF)
    {
        if (comentario)
        {
            if (c == '*')
            {
                prox_c = getc(entrada);
                if (prox_c == '/')
                    comentario = false;
                else
                    ungetc(prox_c, entrada);
            }
        }
        else
        {
            if (c == '/')
            {
                prox_c = getc(entrada);
                if (prox_c == '*')
                    comentario = true;
                else
                    ungetc(prox_c, entrada);
            }

            if (!comentario)
                putc(c, saida);
        }
    }
}
