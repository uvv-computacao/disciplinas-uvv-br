/**
 * Arquivo: rand_max.c
 * Versão : 1.0
 * Data   : 2025-03-09 09:57
 * -------------------------
 * Este programa ilustra o comportamento da função "rand", definida na
 * biblioteca stdlib.h.
 */

/*** Includes ***/

#include <stdio.h>
#include <stdlib.h>

/*** Constantes Simbólicas ***/

#define CHAMADAS 10

/*** Função Main: ***/

int main (void)
{
    printf("Neste computador RAND_MAX é %d.\n", RAND_MAX);
    printf("As primeiras %d chamadas à função \"rand\" são:\n", CHAMADAS);
    for (size_t i = 0; i < CHAMADAS; i++)
        printf("%10d\n", rand());
}
