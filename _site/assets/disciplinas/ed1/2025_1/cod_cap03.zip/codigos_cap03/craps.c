/**
 * Arquivo: craps.c
 * ----------------
 * Este programa simula uma parte do jogo de cassino chamado "Craps", que é
 * jogado com um par de dados. No início do jogo você joga os dados e calcula o
 * total. Se o resultado dessa primeira jogada for 7 ou 11, você ganha o jogo
 * com o resultado que os jogadores chamam de "natural". Se o resultado dessa
 * primeira jogada for 2, 3 ou 12, você perde o jogo com o resultado que os
 * jogadores chamam de "craps". Em qualquer outra situação o total obtido
 * torna-se a "pontuação" e você deve continuar a jogar os dados novamente até
 * que você obtenha novamente a "pontuação" (e ganhar o jogo) ou até que você
 * obtenha um 7 (e perder o jogo); outros totais, incluindo o 2, 3, 11 e 12 não
 * têm nenhum efeito sobre essa fase do jogo.
 */

#include "aleatorio.h"
#include <stdbool.h>
#include <stdio.h>

/* Protótipos */

/**
 * Função: jogar_dados
 * Uso: total = jogar_dados( );
 * ---------------------------
 * Esta função joga dois dados independentes e retorna a soma dos resultados.
 * Como efeito colateral o resultado é exibido na tela.
 */

static int jogar_dados (void);

/**
 * Predicado: obter_pontuacao
 * Uso: flag = obter_pontuacao(pontuacao);
 * ---------------------------------------
 * Este predicado é responsável pela parte do jogo onde você joga os dados
 * repetidas vezes até que você obtenha sua pontuação ou um 7. O predicado
 * retorna TRUE se você obteve a pontuação, e FALSE se obteve 7, o que ocorrer
 * primeiro. Outros resultados não têm efeito nenhum.
 */

static bool obter_pontuacao (int pontuacao);

/* Programa principal */

int main (void)
{
    int pontuacao = 0;

    randomizar();

    printf("Este programa joga uma partida de \"Craps\".\n");
    pontuacao = jogar_dados();

    switch (pontuacao)
    {
    case 7: case 11:
        printf("Você obteve %d, um natural, e você ganhou!\n", pontuacao);
        break;
    case 2: case 3: case 12:
        printf("Você obteve %d, um craps, e você perdeu.\n", pontuacao);
        break;
    default:
        printf("Sua pontuação é %d.\n", pontuacao);
        if (obter_pontuacao(pontuacao))
            printf("Você obteve a pontuação, você ganhou!\n");
        else
            printf("Você obteve um 7, você perdeu.\n");
        break;
    }

    return 0;
}

/* Definições de subprogramas */

/**
 * Função: jogar_dados
 * Uso: total = jogar_dados( );
 * ---------------------------
 */

static int jogar_dados (void)
{
    int d1, d2, total;

    printf("Jogando os dados . . .\n");
    d1 = inteiro_aleatorio(1, 6);
    d2 = inteiro_aleatorio(1, 6);
    total = d1 + d2;
    printf("Os dados foram %d e %d, com total de %d.\n", d1, d2, total);
    return total;
}

/**
 * Predicado: obter_pontuacao
 * Uso: flag = obter_pontuacao(pontuacao);
 * ---------------------------------------
 */

static bool obter_pontuacao (int pontuacao)
{
    int resultado = 0;
    while (true)
    {
        resultado = jogar_dados();
        if (resultado == pontuacao) return true;
        if (resultado == 7) return false;
    }
}

