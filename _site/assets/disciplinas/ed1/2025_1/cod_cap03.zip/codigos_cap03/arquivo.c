#include <stdio.h>

int main (void)
{
    FILE *arq_entrada, *arq_saida;

    arq_entrada = fopen("batatinha.txt", "r");
    if (arq_entrada == NULL)
    {
        printf("ERRO! Não foi possível abrir o arquivo.\n");
        return 1;
    }

    fclose(arq_entrada);

    
}
