/**
 * Arquivo: copiar_arquivo.c
 * -------------------------
 * Este programa demonstra a cópia de um arquivo para outro utilizando
 * transferência caractere a caractere (character I/O).
 */

#include "genlib.h"
#include "simpio.h"
#include <stdio.h>

/* Protótipos de subprogramas */

static void copiar_arquivo(FILE *entrada, FILE *saida);
static FILE *abrir_arquivo(string prompt, string modo);

/* Função main */

int main (void)
{
    FILE *entrada, *saida;

    printf("Este programa copia um arquivo para outro.\n");

    entrada = abrir_arquivo("Arquivo antigo: ", "r");
    if (entrada == NULL)
    {
        printf("Erro ao abrir o arquivo antigo.\n");
        return 1;
    }

    saida = abrir_arquivo("Arquivo novo  : ", "w");
    if (saida == NULL)
    {
        printf("Erro ao abrir o arquivo novo.\n");
        return 2;
    }

    copiar_arquivo(entrada, saida);

    fclose(entrada);
    fclose(saida);
}

/**
 * Função: abrir_arquivo
 * Uso: ptr = abrir_arquivo(prompt, modo);
 * ---------------------------------------
 * Esta função pede ao usuário que informe um nome de arquivo, usando o prompt
 * informado, e então tenta abrir o arquivo usando o modo especificado. Se o
 * arquivo for aberto com sucesso, retorna um ponteiro para arquivo. Se a
 * abertura falhar, é exibida uma mensagem para o usuário e ele deve tentar
 * informar o nome do arquivo novamente.
 */

static FILE *abrir_arquivo(string prompt, string modo)
{
    string nome_do_arquivo;
    FILE *resultado;

    while (TRUE)
    {
        printf("%s", prompt);
        nome_do_arquivo = GetLine();
        if (nome_do_arquivo != NULL)
        {
            resultado = fopen(nome_do_arquivo, modo);
            if (resultado != NULL) break;
        }
        else if (nome_do_arquivo == NULL)
            return NULL;
        printf("Não foi possível abrir o arquivo \"%s\"\n", nome_do_arquivo);
    }

    return resultado;
}

/**
 * Procedimento: copiar_arquivo
 * Uso: copiar_arquivo(entrada, saida);
 * ------------------------------------
 * Este procedimento copia o conteúdo da entrada para a saída. O cliente é
 * responsável por abrir esses arquivos antes de chamar este procedimento, e
 * por fechar esses arquivos depois.
 */

static void copiar_arquivo(FILE *entrada, FILE *saida)
{
    // Tem que ser int para capturar EOF!
    int c;

    while ((c = getc(entrada)) != EOF)
    {
        putc(c, saida);
    }
}


static void copiar_removendo_comentarios(FILE *entrada, FILE *saida)
{
    int c, pc;
    bool e_comentario = FALSE;

    while ((c = getc(engrada)) != EOF)
    {
        if (e_comentario)
        {
            if (c == '*')
            {
                pc = getc(entrada);
                if (pc == '/')
                    e_comentario = FALSE;
                else
                    ungetc(pc, entrada);
            }
        }
        else
        {
            if (c == '/')
            {
                pc = getc(entrada);
                if (pc == '*')
                    e_comentario = TRUE;
                else
                    ungetc(pc, entrada);
            }
            if (!e_comentario) putc(c, saida);
        }
    }
}
