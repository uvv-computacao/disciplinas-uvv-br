#include <stdio.h>

int main (void)
{
    double d = 1234.5678;
    printf("%9.4f\n", d);
    printf("%10.4f\n", d);
}
