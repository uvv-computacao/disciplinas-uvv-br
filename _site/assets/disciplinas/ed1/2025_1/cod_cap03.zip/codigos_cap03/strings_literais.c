#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main (void)
{
    static char ola1[] = "Ola, mundo!";
    char *ola2 = "Ola, mundo!";
    char *ola3 = malloc(sizeof(char) * (strlen("Ola, mundo!") + 1));
    strcpy(ola3, "Ola, mundo!");

    printf("%s\n%s\n%s\n", ola1, ola2, ola3);

    ola1[5] = 'M';
    //ola2[5] = 'M';   // ERRO! Mas o compilador não reclama!
                       // O problema ocorre em execução!
    ola3[5] = 'M';

    printf("%s\n%s\n%s\n", ola1, ola2, ola3);

    free(ola3);
}

