/**
 * Arquivo: geometriaTAD.c
 * Versão : 1.0
 * Data   : 2024-10-14 21:43
 * -------------------------
 * Este programa implementa um cliente simples para demonstrar o uso de tipos
 * abstratos de dados criados pelo usuário, o Ponto2D e o Ponto3D.
 *
 * Prof.: Abrantes Araújo Silva Filho (Computação Raiz)
 *            www.computacaoraiz.com.br
 *            www.youtube.com.br/computacaoraiz
 *            github.com/computacaoraiz
 *            twitter.com/ComputacaoRaiz
 *            www.linkedin.com/company/computacaoraiz
 *            www.abrantes.pro.br
 *            github.com/abrantesasf
 */

#include "genlib.h"
#include "pontoTAD.h"
#include "simpio.h"

/* Função Main: */

int main (void)
{
    // Cria pontos:
    Ponto2D P = criar_Ponto2D(0.0, 0.0);
    Ponto2D Q = criar_Ponto2D(3.0, 4.0);

    Ponto3D W = criar_Ponto3D(0.0, 0.0, 0.0);
    Ponto3D T = criar_Ponto3D(3.0, 3.0, 3.0);

    // Testa gets e cálculo das distâncias:
    printf("Distância entre (%.1f, %.1f) e (%.1f, %.1f): %.5f\n",
           Ponto2D_getX(P), Ponto2D_getY(P), Ponto2D_getX(Q), Ponto2D_getY(Q),
           euclidiana_2d(P, Q));

    printf("Distância entre (%.1f, %.1f, %.1f) e (%.1f, %.1f, %.1f): %.5f\n",
           Ponto3D_getX(W), Ponto3D_getY(W), Ponto3D_getZ(W),
           Ponto3D_getX(T), Ponto3D_getY(T), Ponto3D_getZ(T),
           euclidiana_3d(W, T));

    // Testa sets:
    Ponto2D_setX(P, 3.0);
    Ponto2D_setY(P, 4.0);

    Ponto3D_setX(W, 3.0);
    Ponto3D_setY(W, 3.0);
    Ponto3D_setZ(W, 3.0);

    // Verifica sets:
    printf("Distância entre (%.1f, %.1f) e (%.1f, %.1f): %.5f\n",
           Ponto2D_getX(P), Ponto2D_getY(P), Ponto2D_getX(Q), Ponto2D_getY(Q),
           euclidiana_2d(P, Q));

    printf("Distância entre (%.1f, %.1f, %.1f) e (%.1f, %.1f, %.1f): %.5f\n",
           Ponto3D_getX(W), Ponto3D_getY(W), Ponto3D_getZ(W),
           Ponto3D_getX(T), Ponto3D_getY(T), Ponto3D_getZ(T),
           euclidiana_3d(W, T));

    // Testa desalocação de pontos:
    apagar_Ponto2D(&P);
    apagar_Ponto2D(&Q);
    apagar_Ponto3D(&W);
    apagar_Ponto3D(&T);

    // Tem que dar erro:
    //Ponto2D_setX(P, 3.0);
    
    return 0;
}
