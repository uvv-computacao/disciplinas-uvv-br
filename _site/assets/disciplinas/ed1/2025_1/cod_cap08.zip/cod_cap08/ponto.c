/**
 * Arquivo: ponto.c
 * Versão : 1.0
 * Data   : 2024-10-14 16:43
 * -------------------------
 * Este arquivo implementa a interface ponto.h.
 *
 * Prof.: Abrantes Araújo Silva Filho (Computação Raiz)
 *            www.computacaoraiz.com.br
 *            www.youtube.com.br/computacaoraiz
 *            github.com/computacaoraiz
 *            twitter.com/ComputacaoRaiz
 *            www.linkedin.com/company/computacaoraiz
 *            www.abrantes.pro.br
 *            github.com/abrantesasf
 */

/* Includes: */

#include "ponto.h"

/**
 * FUNÇÃO: euclidiana_2d
 * Uso: euclidiana_2d(Ponto2D, Ponto2D);
 * -------------------------------------
 * A função recebe como argumentos dois Ponto2D e retorna a distância
 * Euclidiana entre esses dois pontos, no plano.
 */

double euclidiana_2d (Ponto2D P, Ponto2D Q)
{
    return sqrt(pow((P.x - Q.x), 2.0) +
                pow((P.y - Q.y), 2.0));
}

/**
 * FUNÇÃO: euclidiana_2d
 * Uso: euclidiana_2d(Ponto2D, Ponto2D);
 * -------------------------------------
 * A função recebe como argumentos dois Ponto2D e retorna a distância
 * Euclidiana entre esses dois pontos, no plano.
 */

double euclidiana_3d (Ponto3D P, Ponto3D Q)
{
    return sqrt(pow((P.x - Q.x), 2.0) +
                pow((P.y - Q.y), 2.0) +
                pow((P.z - Q.z), 2.0));
}

