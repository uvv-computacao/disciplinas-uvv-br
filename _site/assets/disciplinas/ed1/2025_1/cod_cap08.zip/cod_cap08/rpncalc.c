/**
 * Arquivo: rpncalc.c
 * Versão : 1.0
 * Data   : 2024-10-17 11:40
 * -------------------------
 * Este programa simula uma calculadora eletrônica que utiliza a notação
 * polonesa reversa (RPN) para a entrada de dados e operações.
 *
 * Baseado em: Programming Abstractions in C, de Eric S. Roberts.
 *             Capítulo 8: Abstract Data Types (pg. 338-342).
 *
 * Prof.: Abrantes Araújo Silva Filho (Computação Raiz)
 *            www.computacaoraiz.com.br
 *            www.youtube.com.br/computacaoraiz
 *            github.com/computacaoraiz
 *            twitter.com/ComputacaoRaiz
 *            www.linkedin.com/company/computacaoraiz
 *            www.abrantes.pro.br
 *            github.com/abrantesasf
 */

#include <ctype.h>
#include "genlib.h"
#include "simpio.h"
#include "stackTAD1.h"
#include "strlib.h"

/* Constantes Simbólicas: */

/* Declarações de Subprogramas: */

static void aplicar_operador (char op, stackTAD pilha);
static void ajuda (void);
static void limpar_stack (stackTAD pilha);
static void mostrar_stack (stackTAD pilha);

/* Função Main: */

int main (void)
{
    stackTAD pilha;
    string linha;
    char c;

    printf("Simulação de Calculadora RPN (digite A para ajuda)\n");
    pilha = criar_stackTAD();

    while (TRUE)
    {
        printf("> ");
        linha = GetLine();
        c = toupper(linha[0]);

        switch (c)
        {
        case 'S': exit(0); break;
        case 'A': ajuda(); break;
        case 'L': limpar_stack(pilha); break;
        case 'M': mostrar_stack(pilha); break;
        default:
            if (isdigit(c) || c == '.')
            {
                push(pilha, StringToReal(linha));
            }
            else if (c == '+' || c == '-' || c == '*' || c == '/')
            {
                aplicar_operador(c, pilha);
            }
            else
                printf("Comando inválido, informe novamente...\n");
            break;
        }
    }
}

/* Definições de Subprogramas: */

/**
 * PROCEDIMENTO: aplicar_operador
 * Uso: aplicar_operador(cp, pilha);
 * ---------------------------------
 * Este procedimento aplica o operador informado pelo usuário aos dois elementos
 * no topo do stack. Como os operandos do stack são removidos em ordem reversa,
 * o operando da direita é removido antes do operando da esquerda.
 */

static void aplicar_operador (char op, stackTAD pilha)
{
    double esq, dir, resultado;

    dir = pop(pilha);
    esq = pop(pilha);

    switch (op)
    {
    case '+': resultado = esq + dir; break;
    case '-': resultado = esq - dir; break;
    case '*': resultado = esq * dir; break;
    case '/': resultado = esq / dir; break;
    default:
        Error("Operador ilegal: %c", op);
    }

    printf("%g\n", resultado);

    push(pilha, resultado);
}

/**
 * PROCEDIMENTO: ajuda
 * Uso: ajuda( );
 * -------------------
 * Este procedimento gera uma pequena mensagem de ajuda para o usuário.
 */

static void ajuda (void)
{
    printf("Digite as expressões em notação RPN,\n");
    printf("na qual os operadores são colocados após,\n");
    printf("os operandos. Separe os operandos com um\n");
    printf("ENTER. Cada linha da calculadora recebe\n");
    printf("um operador (+, -, *, /), um número, ou um\n");
    printf("dos seguintes comandos:\n");
    printf("  S -- sai do programa\n");
    printf("  A -- mostra esta ajuda\n");
    printf("  L -- limpar a pilha da calculadora\n");
    printf("  M -- mostrar todos os valores na pilha\n");
}

/**
 * PROCEDIMENTO: limpar_stack
 * Uso: limpar_stack(pilha);
 * --------------------------
 * Este procedimento retira todos os elementos da pilha, fazendo pop até que
 * não reste mais nenhum.
 */

static void limpar_stack (stackTAD pilha)
{
    while (!vazia(pilha))
        (void) pop(pilha);
}

/**
 * PROCEDIMENTO: mostrar_stack
 * Uso: mostrar_stack(pilha);
 * ---------------------------
 * Este procedimento mostra o conteúdo da pilha da calculadora.
 */

static void mostrar_stack (stackTAD pilha)
{
    printf("Pilha: \n");
    int qtd = qtd_elementos(pilha);

    if (qtd == 0)
        printf("vazia\n");
    else
        imprimir_stack(pilha, qtd);
}
