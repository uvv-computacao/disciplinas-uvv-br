/**
 * Arquivo: stackTAD_teste2.c
 * Versão : 1.0
 * Data   : 2024-10-16 17:34
 * -------------------------
 * Este arquivo implementa um pequeno programa cliente de teste para a
 * implementação stackTAD2.o da interface stackTAD1.h (com pilha sem tamanho
 * máximo pré-definido, alocada estaticamente).
 *
 * Baseado em: Programming Abstractions in C, de Eric S. Roberts.
 *             Capítulo 8: Abstract Data Types (pg. 327-347).
 *
 * Prof.: Abrantes Araújo Silva Filho (Computação Raiz)
 *            www.computacaoraiz.com.br
 *            www.youtube.com.br/computacaoraiz
 *            github.com/computacaoraiz
 *            twitter.com/ComputacaoRaiz
 *            www.linkedin.com/company/computacaoraiz
 *            www.abrantes.pro.br
 *            github.com/abrantesasf
 */

#include "genlib.h"
#include "simpio.h"
#include "stackTAD1.h"
#include "strlib.h"

/* Função Main: */

int main (void)
{
    stackTAD pilha = criar_stackTAD();
    
    push(pilha, 10.1);
    printf("Qtd. elementos: %ld\n", qtd_elementos(pilha));
    push(pilha, 20.2);
    printf("Qtd. elementos: %ld\n", qtd_elementos(pilha));
    push(pilha, 30.3);
    printf("Qtd. elementos: %ld\n", qtd_elementos(pilha));
    push(pilha, 40.4);
    printf("Qtd. elementos: %ld\n", qtd_elementos(pilha));
    push(pilha, 50.5);
    printf("Qtd. elementos: %ld\n", qtd_elementos(pilha));
    push(pilha, 60.6);
    printf("Qtd. elementos: %ld\n", qtd_elementos(pilha));

    elementoT item;
    item = pop(pilha);
    printf("Item %g\n", item);
    printf("Qtd. elementos: %ld\n", qtd_elementos(pilha));
    item = pop(pilha);
    printf("Item %g\n", item);
    printf("Qtd. elementos: %ld\n", qtd_elementos(pilha));
    item = pop(pilha);
    printf("Item %g\n", item);
    printf("Qtd. elementos: %ld\n", qtd_elementos(pilha));
    item = pop(pilha);
    printf("Item %g\n", item);
    printf("Qtd. elementos: %ld\n", qtd_elementos(pilha));
    item = pop(pilha);
    printf("Item %g\n", item);
    printf("Qtd. elementos: %ld\n", qtd_elementos(pilha));
    item = pop(pilha);
    printf("Item %g\n", item);
    printf("Qtd. elementos: %ld\n", qtd_elementos(pilha));

    item = pop(pilha);
    printf("Item %g\n", item);
    printf("Qtd. elementos: %ld\n", qtd_elementos(pilha));

    remover_stackTAD(&pilha);
}
