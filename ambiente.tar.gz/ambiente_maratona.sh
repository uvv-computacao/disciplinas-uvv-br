#!/bin/bash


#------------------------------------------------------------------------------#
# Utilitários necessários para as configurações iniciais                       #
#------------------------------------------------------------------------------#
apt install wget curl libcurl4-openssl-dev gnupg gnupg-agent apt-transport-https
apt install ca-certificates software-properties-common texinfo dirmngr


#------------------------------------------------------------------------------#
# Adiciona repositórios importantes                                            #
#------------------------------------------------------------------------------#
# Repositóio para o Wine, habilitando suporte para 32 bits:
#dpkg --add-architecture i386
#wget -nc -O /usr/share/keyrings/winehq-archive.key https://dl.winehq.org/wine-builds/winehq.key
#wget -NP /etc/apt/sources.list.d/ https://dl.winehq.org/wine-builds/ubuntu/dists/jammy/winehq-jammy.sources

# Repositório da Toolchain para compiladores C/C++:
add-apt-repository ppa:ubuntu-toolchain-r/ppa
add-apt-repository ppa:ubuntu-toolchain-r/test

# Repositórios para compiladores Clang:
#echo "# Main" > clang.list
#echo "deb http://apt.llvm.org/$(lsb_release -cs)/ llvm-toolchain-$(lsb_release -cs) main" >> clang.list
#echo "deb-src http://apt.llvm.org/$(lsb_release -cs)/ llvm-toolchain-$(lsb_release -cs) main" >> clang.list
#echo "# 17" >> clang.list
#echo "deb http://apt.llvm.org/$(lsb_release -cs)/ llvm-toolchain-$(lsb_release -cs)-17 main" >> clang.list
#echo "deb-src http://apt.llvm.org/$(lsb_release -cs)/ llvm-toolchain-$(lsb_release -cs)-17 main" >> clang.list
#echo "# 18" >> clang.list
#echo "deb http://apt.llvm.org/$(lsb_release -cs)/ llvm-toolchain-$(lsb_release -cs)-18 main" >> clang.list
#echo "deb-src http://apt.llvm.org/$(lsb_release -cs)/ llvm-toolchain-$(lsb_release -cs)-18 main" >> clang.list
#wget -qO- https://apt.llvm.org/llvm-snapshot.gpg.key | tee /etc/apt/trusted.gpg.d/apt.llvm.org.asc

# Repositório para o OBS Studio
#add-apt-repository ppa:obsproject/obs-studio

# Repositóriop para o Syncthing
#curl -o /usr/share/keyrings/syncthing-archive-keyring.gpg https://syncthing.net/release-key.gpg
#echo "deb [signed-by=/usr/share/keyrings/syncthing-archive-keyring.gpg] https://apt.syncthing.net/ syncthing stable" | sudo tee /etc/apt/sources.list.d/syncthing.list

# Repositório para o Docker:
#curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker.gpg
#echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# Repositório para o Aegisub:
#add-apt-repository ppa:alex-p/aegisub

# Repositório para o PostgreSQL
#curl -fsSL https://www.postgresql.org/media/keys/ACCC4CF8.asc | gpg --dearmor -o /usr/share/keyrings/postgresql.gpg
#echo "deb [arch=amd64 signed-by=/usr/share/keyrings/postgresql.gpg] http://apt.postgresql.org/pub/repos/apt/ jammy-pgdg main" >> /etc/apt/sources.list.d/pgdg.list

# Reositório para o pgAdmin
#curl -fsSL https://www.pgadmin.org/static/packages_pgadmin_org.pub | gpg --dearmor -o /usr/share/keyrings/pgadmin.gpg
#echo "deb [arch=amd64 signed-by=/usr/share/keyrings/pgadmin.gpg] https://ftp.postgresql.org/pub/pgadmin/pgadmin4/apt/$(lsb_release -cs) pgadmin4 main" > /etc/apt/sources.list.d/pgadmin4.list

# Repositório para o MariaDB 10.11
#mkdir -p /etc/apt/keyrings
#curl -o /etc/apt/keyrings/mariadb-keyring.pgp 'https://mariadb.org/mariadb_release_signing_key.pgp'
#echo "deb [arch=amd64 signed-by=/etc/apt/keyrings/mariadb-keyring.pgp] https://atl.mirrors.knownhost.com/mariadb/repo/10.11/ubuntu jammy main" > /etc/apt/sources.list.d/mariadb.list

# Repositório para o MongoDB
#wget -qO - https://www.mongodb.org/static/pgp/server-4.4.asc | sudo apt-key add -
#echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu focal/mongodb-org/4.4 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-4.4.list

# Repolsitório para o Geogebra
#apt-key adv --fetch-keys 'https://static.geogebra.org/linux/office@geogebra.org.gpg.key'
#apt-add-repository -u 'deb http://www.geogebra.net/linux/ stable main'

# Repositório para o VSCodium
#wget -qO - https://gitlab.com/paulcarroty/vscodium-deb-rpm-repo/raw/master/pub.gpg \
#    | gpg --dearmor \
#    | sudo dd of=/usr/share/keyrings/vscodium-archive-keyring.gpg
#echo 'deb [ signed-by=/usr/share/keyrings/vscodium-archive-keyring.gpg ] https://download.vscodium.com/debs vscodium main' \
#    | sudo tee /etc/apt/sources.list.d/vscodium.list

# Repositório para o VSCode
wget -qO- https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor > packages.microsoft.gpg
install -D -o root -g root -m 644 packages.microsoft.gpg /etc/apt/keyrings/packages.microsoft.gpg
echo "deb [arch=amd64,arm64,armhf signed-by=/etc/apt/keyrings/packages.microsoft.gpg] https://packages.microsoft.com/repos/code stable main" > /etc/apt/sources.list.d/vscode.list
rm -f packages.microsoft.gpg

# Repositório para a versão atual do Git
add-apt-repository ppa:git-core/ppa

# Repositório para o VirtualBox
#curl https://www.virtualbox.org/download/oracle_vbox_2016.asc | gpg --dearmor > oracle_vbox_2016.gpg
#curl https://www.virtualbox.org/download/oracle_vbox.asc | gpg --dearmor > oracle_vbox.gpg
#install -o root -g root -m 644 oracle_vbox_2016.gpg /etc/apt/trusted.gpg.d/
#install -o root -g root -m 644 oracle_vbox.gpg /etc/apt/trusted.gpg.d/
#echo "deb [arch=amd64] http://download.virtualbox.org/virtualbox/debian $(lsb_release -sc) contrib" | sudo tee /etc/apt/sources.list.d/virtualbox.list

# Repositório para o Prolog
#apt-add-repository ppa:swi-prolog/stable


#------------------------------------------------------------------------------#
# Renova lista de pacotes e atualiza já instalados                             #
#------------------------------------------------------------------------------#
apt update
apt upgrade


#------------------------------------------------------------------------------#
# Uma porrada de bibliotecas que são pré-requisitos para outras coisas e que   #
# não tenho paciência para ficar descrevendo... apenas instale!                #
#------------------------------------------------------------------------------#
apt install libtiff-dev libgif-dev libjpeg-dev libpng-dev libxpm-dev
apt install imagemagick imageinfo libmagickwand-dev
apt install libwxgtk3.0-gtk3-0v5 libwxgtk3.0-gtk3-dev libwxsvg3 libwxsvg-dev libwxsvg-tools
apt install libgtk-3-0 libgtk-3-bin libgtk-3-common libgtk-3-dev
apt install libwebkit2gtk-4.0-37 libwebkit2gtk-4.0-dev
apt install libncurses-dev libtinfo-dev libncurses5 libtinfo5
apt install libfuse2 libxi6 libxrender1 libxtst6 mesa-utils libfontconfig libgtk-3-bin
apt install autoconf-archive


#------------------------------------------------------------------------------#
# Editores de texto                                                            #
#------------------------------------------------------------------------------#
apt install vim emacs
#snap install codium --classic
apt install code
apt install aspell aspell-en aspell-pt-br dictionaries-common enchant-2
apt install hunspell hunspell-en-gb hunspell-en-us hunspell-pt-br hyphen-en-us


#------------------------------------------------------------------------------#
# Gerenciamento de versões                                                     #
#------------------------------------------------------------------------------#
apt install git


#------------------------------------------------------------------------------#
# Captura de tela (print screen)                                               #
#------------------------------------------------------------------------------#
#apt install shutter
##apt install gnome-web-photo # Não disponível ainda para Ubuntu 20


#------------------------------------------------------------------------------#
# Edição de imagens, fotos e similares                                         #
#------------------------------------------------------------------------------#
#apt install gimp inkscape gpick graphviz


#------------------------------------------------------------------------------#
# Edição de som                                                                #
#------------------------------------------------------------------------------#
#snap install audacity
#apt install ardour soundconverter


#------------------------------------------------------------------------------#
# Edição (e gravação de víde)                                                  #
#------------------------------------------------------------------------------#
#apt install blender kdenlive vlc ffmpeg obs-studio aegisub


#------------------------------------------------------------------------------#
# Emuladores                                                                   #
#------------------------------------------------------------------------------#
# O Winehq ainda não está disponível para o Ubuntu 22, por isso comentei aqui:
# (por causa disso estou usando o CrossOver)
#apt install --install-recommends winehq-stable



#------------------------------------------------------------------------------#
# Compiladores                                                                 #
#------------------------------------------------------------------------------#
# Compilador C/C++:
apt-get install build-essential manpages-dev software-properties-common
apt-get install gcc g++ gcc-13 g++-13 gcc-12 g++-12 gcc-11 g++-11
update-alternatives --install /usr/bin/gcc gcc /usr/bin/gcc-13 90 \
     --slave /usr/bin/g++        g++        /usr/bin/g++-13 \
     --slave /usr/bin/gcc-ar     gcc-ar     /usr/bin/gcc-ar-13 \
     --slave /usr/bin/gcc-nm     gcc-nm     /usr/bin/gcc-nm-13 \
     --slave /usr/bin/gcc-ranlib gcc-ranlib /usr/bin/gcc-ranlib-13
update-alternatives --install /usr/bin/gcc gcc /usr/bin/gcc-12 80 \
     --slave /usr/bin/g++        g++        /usr/bin/g++-12 \
     --slave /usr/bin/gcc-ar     gcc-ar     /usr/bin/gcc-ar-12 \
     --slave /usr/bin/gcc-nm     gcc-nm     /usr/bin/gcc-nm-12 \
     --slave /usr/bin/gcc-ranlib gcc-ranlib /usr/bin/gcc-ranlib-12
update-alternatives --install /usr/bin/gcc gcc /usr/bin/gcc-11 70 \
     --slave /usr/bin/g++        g++        /usr/bin/g++-11 \
     --slave /usr/bin/gcc-ar     gcc-ar     /usr/bin/gcc-ar-11 \
     --slave /usr/bin/gcc-nm     gcc-nm     /usr/bin/gcc-nm-11 \
     --slave /usr/bin/gcc-ranlib gcc-ranlib /usr/bin/gcc-ranlib-11
update-alternatives --install /usr/bin/gcc gcc /usr/bin/gcc-10 60 \
     --slave /usr/bin/g++        g++        /usr/bin/g++-10 \
     --slave /usr/bin/gcc-ar     gcc-ar     /usr/bin/gcc-ar-10 \
     --slave /usr/bin/gcc-nm     gcc-nm     /usr/bin/gcc-nm-10 \
     --slave /usr/bin/gcc-ranlib gcc-ranlib /usr/bin/gcc-ranlib-10

# Compilador Clang:
#apt-get install libllvm-17-ocaml-dev libllvm17 llvm-17 llvm-17-dev llvm-17-doc \
#	llvm-17-examples llvm-17-runtime clang-17 clang-tools-17 \
#	clang-17-doc libclang-common-17-dev libclang-17-dev libclang1-17 \
#	clang-format-17 python3-clang-17 clangd-17 clang-tidy-17 libclang-rt-17-dev \
#	libpolly-17-dev libfuzzer-17-dev lldb-17 lld-17 libc++-17-dev libc++abi-17-dev \
#	libomp-17-dev libclc-17-dev libunwind-17-dev libmlir-17-dev mlir-17-tools \
#	libbolt-17-dev bolt-17 flang-17 libclang-rt-17-dev-wasm32 \
#	libclang-rt-17-dev-wasm64 libc++-17-dev-wasm32 libc++abi-17-dev-wasm32 \
#	libclang-rt-17-dev-wasm32 libclang-rt-17-dev-wasm64
#apt-get install libllvm-18-ocaml-dev libllvm18 llvm-18 llvm-18-dev llvm-18-doc \
#	llvm-18-examples llvm-18-runtime clang-18 clang-tools-18 clang-18-doc \
#	libclang-common-18-dev libclang-18-dev libclang1-18 clang-format-18 \
#	python3-clang-18 clangd-18 clang-tidy-18 libclang-rt-18-dev libfuzzer-18-dev \
#	lldb-18 lld-18 libc++-18-dev libc++abi-18-dev libomp-18-dev \
#	libclc-18-dev libunwind-18-dev libmlir-18-dev mlir-18-tools \
#	libbolt-18-dev bolt-18 flang-18 libclang-rt-18-dev-wasm32 \
#	libclang-rt-18-dev-wasm64 libc++-18-dev-wasm32 libc++abi-18-dev-wasm32 \
#	libclang-rt-18-dev-wasm32 libclang-rt-18-dev-wasm64 libllvmlibc-18-dev
#update-alternatives --install /usr/bin/clang clang /usr/bin/clang-18 90 \
#     --slave /usr/bin/clang++                  clang++                  /usr/bin/clang++-18 \
#     --slave /usr/bin/clang-apply-replacements clang-apply-replacements /usr/bin/clang-apply-replacements-18 \
#     --slave /usr/bin/clang-change-namespace   clang-change-namespace   /usr/bin/clang-change-namespace-18 \
#     --slave /usr/bin/clang-check              clang-check              /usr/bin/clang-check-18 \
#     --slave /usr/bin/clang-cl                 clang-cl                 /usr/bin/clang-cl-18 \
#     --slave /usr/bin/clang-cpp                clang-cpp                /usr/bin/clang-cpp-18 \
#     --slave /usr/bin/clangd                   clangd                   /usr/bin/clangd-18 \
#     --slave /usr/bin/clang-doc                clang-doc                /usr/bin/clang-doc-18 \
#     --slave /usr/bin/clang-extdef-mapping     clang-extdef-mapping     /usr/bin/clang-extdef-mapping-18 \
#     --slave /usr/bin/clang-format             clang-format             /usr/bin/clang-format-18 \
#     --slave /usr/bin/clang-format-diff        clang-format-diff        /usr/bin/clang-format-diff-18 \
#     --slave /usr/bin/clang-include-cleaner    clang-include-cleaner    /usr/bin/clang-include-cleaner-18 \
#     --slave /usr/bin/clang-include-fixer      clang-include-fixer      /usr/bin/clang-include-fixer-18 \
#     --slave /usr/bin/clang-linker-wrapper     clang-linker-wrapper     /usr/bin/clang-linker-wrapper-18 \
#     --slave /usr/bin/clang-move               clang-move               /usr/bin/clang-move-18 \
#     --slave /usr/bin/clang-offload-bundler    clang-offload-bundler    /usr/bin/clang-offload-bundler-18 \
#     --slave /usr/bin/clang-offload-packager   clang-offload-packager   /usr/bin/clang-offload-packager-18 \
#     --slave /usr/bin/clang-pseudo             clang-pseudo             /usr/bin/clang-pseudo-18 \
#     --slave /usr/bin/clang-query              clang-query              /usr/bin/clang-query-18 \
#     --slave /usr/bin/clang-refactor           clang-refactor           /usr/bin/clang-refactor-18 \
#     --slave /usr/bin/clang-rename             clang-rename             /usr/bin/clang-rename-18 \
#     --slave /usr/bin/clang-reorder-fields     clang-reorder-fields     /usr/bin/clang-reorder-fields-18 \
#     --slave /usr/bin/clang-repl               clang-repl               /usr/bin/clang-repl-18 \
#     --slave /usr/bin/clang-scan-deps          clang-scan-deps          /usr/bin/clang-scan-deps-18 \
#     --slave /usr/bin/clang-tblgen             clang-tblgen             /usr/bin/clang-tblgen-18 \
#     --slave /usr/bin/clang-tidy               clang-tidy               /usr/bin/clang-tidy-18
#update-alternatives --install /usr/bin/clang clang /usr/bin/clang-17 80 \
#     --slave /usr/bin/clang++                  clang++                  /usr/bin/clang++-17 \
#     --slave /usr/bin/clang-apply-replacements clang-apply-replacements /usr/bin/clang-apply-replacements-17 \
#     --slave /usr/bin/clang-change-namespace   clang-change-namespace   /usr/bin/clang-change-namespace-17 \
#     --slave /usr/bin/clang-check              clang-check              /usr/bin/clang-check-17 \
#     --slave /usr/bin/clang-cl                 clang-cl                 /usr/bin/clang-cl-17 \
#     --slave /usr/bin/clang-cpp                clang-cpp                /usr/bin/clang-cpp-17 \
#     --slave /usr/bin/clangd                   clangd                   /usr/bin/clangd-17 \
#     --slave /usr/bin/clang-doc                clang-doc                /usr/bin/clang-doc-17 \
#     --slave /usr/bin/clang-extdef-mapping     clang-extdef-mapping     /usr/bin/clang-extdef-mapping-17 \
#     --slave /usr/bin/clang-format             clang-format             /usr/bin/clang-format-17 \
#     --slave /usr/bin/clang-format-diff        clang-format-diff        /usr/bin/clang-format-diff-17 \
#     --slave /usr/bin/clang-include-cleaner    clang-include-cleaner    /usr/bin/clang-include-cleaner-17 \
#     --slave /usr/bin/clang-include-fixer      clang-include-fixer      /usr/bin/clang-include-fixer-17 \
#     --slave /usr/bin/clang-linker-wrapper     clang-linker-wrapper     /usr/bin/clang-linker-wrapper-17 \
#     --slave /usr/bin/clang-move               clang-move               /usr/bin/clang-move-17 \
#     --slave /usr/bin/clang-offload-bundler    clang-offload-bundler    /usr/bin/clang-offload-bundler-17 \
#     --slave /usr/bin/clang-offload-packager   clang-offload-packager   /usr/bin/clang-offload-packager-17 \
#     --slave /usr/bin/clang-pseudo             clang-pseudo             /usr/bin/clang-pseudo-17 \
#     --slave /usr/bin/clang-query              clang-query              /usr/bin/clang-query-17 \
#     --slave /usr/bin/clang-refactor           clang-refactor           /usr/bin/clang-refactor-17 \
#     --slave /usr/bin/clang-rename             clang-rename             /usr/bin/clang-rename-17 \
#     --slave /usr/bin/clang-reorder-fields     clang-reorder-fields     /usr/bin/clang-reorder-fields-17 \
#     --slave /usr/bin/clang-repl               clang-repl               /usr/bin/clang-repl-17 \
#     --slave /usr/bin/clang-scan-deps          clang-scan-deps          /usr/bin/clang-scan-deps-17 \
#     --slave /usr/bin/clang-tblgen             clang-tblgen             /usr/bin/clang-tblgen-17 \
#     --slave /usr/bin/clang-tidy               clang-tidy               /usr/bin/clang-tidy-17


#------------------------------------------------------------------------------#
# Acesso remoto                                                                #
#------------------------------------------------------------------------------#
#apt install remmina
apt install openssh-server
systemctl enable ssh
systemctl start ssh
#snap install teams-for-linux


#------------------------------------------------------------------------------#
# Administração de redes e de sistemas                                         #
#------------------------------------------------------------------------------#
#apt install net-tools wireshark ipcalc gip cifs-utils
apt install net-tools ipcalc gip cifs-utils
apt install ncal libtool-bin autoconf-archive


#------------------------------------------------------------------------------#
# Certificados SSL, segurança, autenticação e relacionados                     #
#------------------------------------------------------------------------------#
#apt install certbot
#snap install core
#snap refresh core
#snap install --classic certbot
#ln -s /snap/bin/certbot /usr/bin/certbot

apt install gnutls-bin libgnutls28-dev xauth

apt install pinentry-tty
update-alternatives --config pinentry
apt install pwgen


#------------------------------------------------------------------------------#
# Ferramentas de disco, CD, etc.                                               #
#------------------------------------------------------------------------------#
#apt install gparted gnome-disk-utility brasero
#apt install unetbootin


#------------------------------------------------------------------------------#
# Instalar e configurar Java                                                   #
#------------------------------------------------------------------------------#
# Instala diferentes versões do Java:
#apt install openjdk-8-jre-headless
#apt install openjdk-8-jdk
#apt install openjdk-11-jre-headless
#apt install openjdk-11-jdk
apt install openjdk-17-jre-headless
apt install openjdk-17-jdk
# Configure o Java padrão em seu sistema
#echo ""
#echo "Configure o Java padrão em seu sistema:"
#echo ""
#update-alternatives --config java
#update-alternatives --config javac


#------------------------------------------------------------------------------#
# TCL/Tk                                                                       #
#------------------------------------------------------------------------------#
#apt install tcl tcl-dev tcl-tclreadline tcl-thread tcl-tls tdom tdom-dev tk tk-dev


#------------------------------------------------------------------------------#
# Python                                                                       #
#------------------------------------------------------------------------------#
#pt install python2 python2-dev
apt install python3 python3-dev python3-pip python3-tk


#------------------------------------------------------------------------------#
# Ruby                                                                         #
#------------------------------------------------------------------------------#
#apt install ruby-full build-essential zlib1g-dev


#------------------------------------------------------------------------------#
# Shell, scripts, etc.                                                         #
#------------------------------------------------------------------------------#
apt install wish perl-tk dos2unix detox


#------------------------------------------------------------------------------#
# Usenet e relacionados                                                        #
#------------------------------------------------------------------------------#
#apt install hexchat pan
#apt install sabnzbdplus
#apt install mono-devel
#apt install nzbdrone



#------------------------------------------------------------------------------#
# Bancos de dados                                                              #
#------------------------------------------------------------------------------#
# Para o PostgreSQL 14:
#apt install postgresql-14 postgresql-14-asn1oid postgresql-14-auto-failover postgresql-14-cron postgresql-14-extra-window-functions postgresql-14-first-last-agg postgresql-14-hypopg postgresql-14-icu-ext postgresql-14-ip4r postgresql-14-jsquery postgresql-14-mysql-fdw postgresql-14-numeral postgresql-14-orafce postgresql-14-partman postgresql-14-pgauditlogtofile postgresql-14-pgaudit postgresql-14-pg-catcheck postgresql-14-pglogical postgresql-14-pgmemcache postgresql-14-pgmp postgresql-14-pgpcre postgresql-14-pgq3 postgresql-14-pgrouting postgresql-14-pgrouting-scripts postgresql-14-pgsphere postgresql-14-pljava postgresql-14-pllua postgresql-14-plpgsql-check postgresql-14-plr postgresql-14-plsh postgresql-14-postgis-3 postgresql-14-postgis-3-scripts postgresql-14-rational postgresql-14-slony1-2 postgresql-14-tds-fdw postgresql-14-unit postgresql-autodoc postgresql-client-14 postgresql-doc-14 postgresql-plperl-14 postgresql-plpython3-14 postgresql-pltcl-14 postgresql-server-dev-14

# Para o PostgreSQL 15:
#apt install postgresql-15 postgresql-15-asn1oid postgresql-15-auto-failover postgresql-15-bgw-replstatus postgresql-15-cron postgresql-15-extra-window-functions postgresql-15-first-last-agg postgresql-15-hypopg postgresql-15-icu-ext postgresql-15-ip4r postgresql-15-jsquery postgresql-15-mimeo postgresql-15-mysql-fdw postgresql-15-numeral postgresql-15-orafce postgresql-15-partman postgresql-15-pg-catcheck postgresql-15-pg-checksums postgresql-15-pg-fact-loader postgresql-15-pg-qualstats postgresql-15-pg-stat-kcache postgresql-15-pg-track-settings postgresql-15-pg-wait-sampling postgresql-15-pgaudit postgresql-15-pgauditlogtofile postgresql-15-pgextwlist postgresql-15-pgfincore postgresql-15-pgl-ddl-deploy postgresql-15-pglogical postgresql-15-pglogical-ticker postgresql-15-pgmemcache postgresql-15-pgmp postgresql-15-pgpcre postgresql-15-pgpool2 postgresql-15-pgq-node postgresql-15-pgq3 postgresql-15-pgrouting postgresql-15-pgrouting-scripts postgresql-15-pgsphere postgresql-15-pgtap postgresql-15-pldebugger postgresql-15-plpgsql-check postgresql-15-plprofiler postgresql-15-plproxy postgresql-15-plr postgresql-15-plsh postgresql-15-pointcloud postgresql-15-postgis-3 postgresql-15-postgis-3-scripts postgresql-15-powa postgresql-15-preprepare postgresql-15-prioritize postgresql-15-rational postgresql-15-repack postgresql-15-repmgr postgresql-15-set-user postgresql-15-similarity postgresql-15-slony1-2 postgresql-15-tablelog postgresql-15-tds-fdw postgresql-15-unit postgresql-15-wal2json postgresql-client-15 postgresql-doc-15 postgresql-plperl-15 postgresql-plpython3-15 postgresql-pltcl-15 postgresql-server-dev-15 libpgtypes3

# Para o PostgreSQL 16
#apt install postgresql-16 postgresql-16-asn1oid postgresql-16-auto-failover postgresql-16-bgw-replstatus postgresql-16-cron postgresql-16-extra-window-functions postgresql-16-first-last-agg postgresql-16-hypopg postgresql-16-icu-ext postgresql-16-ip4r postgresql-16-jsquery postgresql-16-mimeo postgresql-16-mysql-fdw postgresql-16-numeral postgresql-16-orafce postgresql-16-partman postgresql-16-pg-catcheck postgresql-16-pg-checksums postgresql-16-pg-fact-loader postgresql-16-pg-qualstats postgresql-16-pg-stat-kcache postgresql-16-pg-track-settings postgresql-16-pg-wait-sampling postgresql-16-pgaudit postgresql-16-pgauditlogtofile postgresql-16-pgextwlist postgresql-16-pgfincore postgresql-16-pgl-ddl-deploy postgresql-16-pglogical postgresql-16-pglogical-ticker postgresql-16-pgmemcache postgresql-16-pgmp postgresql-16-pgpcre postgresql-16-pgpool2 postgresql-16-pgq-node postgresql-16-pgq3 postgresql-16-pgrouting postgresql-16-pgrouting-scripts postgresql-16-pgsphere postgresql-16-pgtap postgresql-16-pldebugger postgresql-16-plpgsql-check postgresql-16-plprofiler postgresql-16-plproxy postgresql-16-plr postgresql-16-plsh postgresql-16-pointcloud postgresql-16-postgis-3 postgresql-16-postgis-3-scripts postgresql-16-powa postgresql-16-preprepare postgresql-16-prioritize postgresql-16-rational postgresql-16-repack postgresql-16-repmgr postgresql-16-set-user postgresql-16-similarity postgresql-16-slony1-2 postgresql-16-tablelog postgresql-16-tds-fdw postgresql-16-unit postgresql-16-wal2json postgresql-client-16 postgresql-doc-16 postgresql-plperl-16 postgresql-plpython3-16 postgresql-pltcl-16 postgresql-server-dev-16 libpgtypes3

# PgAdmin4:
#apt install pgadmin4-desktop

# MariaDB:
#apt install mariadb-server
#mysql_secure_installation

# MongoDB:
#apt-get install mongodb-org


#------------------------------------------------------------------------------#
# Gerenciadores de pacotes                                                     #
#------------------------------------------------------------------------------#
#apt install synaptic
#apt install flatpak
#flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo


#------------------------------------------------------------------------------#
# Backup, sincronização e relacionados                                         #
#------------------------------------------------------------------------------#
#apt-get install syncthing
# Ubuntu 22 já tem padrão de 500065, então comentei:
#echo "fs.inotify.max_user_watches=204800" | tee -a /etc/sysctl.conf
#systemctl enable syncthing@abrantesasf.service
#systemctl start syncthing@abrantesasf.service


#------------------------------------------------------------------------------#
# Common Lisp                                                                  #
#------------------------------------------------------------------------------#
#apt install clisp clisp-module-postgresql clisp-module-pcre clisp-module-zlib clisp-module-clx
#apt install libtool-bin libgdbm-dev libmcrypt-dev
#apt install rlwrap


#------------------------------------------------------------------------------#
# SML/NJ                                                                       #
#------------------------------------------------------------------------------#
#dpkg --add-architecture i386
#apt-get install libc6:i386
#apt-get install gcc-multilib g++-multilib


#------------------------------------------------------------------------------#
# SWI Prolog                                                                   #
#------------------------------------------------------------------------------#
#apt-get install swi-prolog


#------------------------------------------------------------------------------#
# Maxima                                                                       #
#------------------------------------------------------------------------------#
#apt install maxima maxima-doc maxima-share wxmaxima xmaxima


#------------------------------------------------------------------------------#
# Geogebra                                                                     #
#------------------------------------------------------------------------------#
#apt install geogebra-classic


#------------------------------------------------------------------------------#
# OpenBoard                                                                    #
#------------------------------------------------------------------------------#
# Packages que são pré-requisitos
#apt install build-essential libgl1-mesa-dev libfontconfig1 libssl-dev libpoppler-dev
#apt install libpoppler-cpp-dev libpoppler-private-dev libavcodec-dev libavformat-dev
#apt install libswscale-dev libpaper-dev libva-dev libxcb-shm0-dev libasound2-dev
#apt install libx264-dev libvpx-dev libvorbis-dev  libtheora-dev libmp3lame-dev
#apt install libsdl1.2-dev libopus-dev  libfdk-aac-dev libass-dev liblzma-dev 
#apt install libbz2-dev libquazip5-dev libxcb-shape0-dev libxcb-xfixes0-dev
# Seguir instruções de instalação do OpenBoard em:
# https://openboard.ch/download.html


#------------------------------------------------------------------------------#
# Instala Ecossistema Docker
#------------------------------------------------------------------------------#
#apt-get remove docker docker-engine docker.io containerd runc
#apt-get install docker-ce docker-ce-cli containerd.io docker-compose-plugin
#groupadd -r docker
#usermod -aG docker abrantesasf
#systemctl enable docker
#systemctl start docker
#systemctl enable containerd
#systemctl start containerd


#------------------------------------------------------------------------------#
# Mesa Wacom                                                                   #
#------------------------------------------------------------------------------#
#apt install kde-config-tablet
#apt install libwacom-bin
#apt install libwacom-common
#apt install libwacom-dev
##apt install libwacom2
#apt install libwacom9
#apt install xserver-xorg-input-wacom
# Para configurar a mesa para apenas 1 monitor:
# 1) Usar "xsetwacom --list" para verificar os dispositivos Wacom instalados;
# 2) Verifique o nome completo do dispositivo marcado como STYLUS
# 3) Se está em um computador sem NVIDIA:
#    a) Usar "xrandr" e verificar quais os monitores reconhecidos
#    b) Mapear a Wacom para um dos monitores com:
#       xsetwacom -v set "Wacom Intuos Pro M Pen stylus" MapToOutput DVI-I-1
# 4) Se está em um computador com NVIDIA:
#    a) Mapear a Wacom para HEAD-0, HEAD-1, etc:
#       xsetwacom -v set "Wacom Intuos Pro M Pen stylus" MapToOutput HEAD-1


#------------------------------------------------------------------------------#
# Instala Virtual Box
#------------------------------------------------------------------------------#
#apt install linux-headers-$(uname -r) dkms
#apt install virtualbox-7.0
# Depois da instalação, coloque seu usário no grupo vboxusers!


#------------------------------------------------------------------------------#
# Instala aplicativos Flatpak
#------------------------------------------------------------------------------#
# Xournal++
#flatpak install flathub com.github.xournalpp.xournalpp
##flatpak install flathub org.freedesktop.Sdk.Extension.texlive


#------------------------------------------------------------------------------#
# Instala as impressoras
#------------------------------------------------------------------------------#
apt install ghostscript

#ln -s /etc/init.d/cupsys /etc/init.d/lpd
#mkdir /var/spool/lpd
#dpkg  -i  --force-all /home/abrantesasf/hl5350dnlpr-2.0.3-1.i386.deb
#dpkg  -i  --force-all /home/abrantesasf/cupswrapperHL5350DN-2.0.4-1.i386.deb


#------------------------------------------------------------------------------#
# Instala fontes opcionais
#------------------------------------------------------------------------------#
#apt install xfonts-100dpi xfonts-75dpi ttf-mscorefonts-installer

